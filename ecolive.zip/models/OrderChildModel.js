var mongoose = require("mongoose");

var Schema = mongoose.Schema;

var OrderChildSchema = new Schema({
	order_id: { type: Schema.ObjectId, ref: "Orders", required: true },
	shop_id: { type: Schema.ObjectId, ref: "Shop", required: true },
	product_id: { type: Schema.ObjectId, ref: "Product", required: true },
	qty: {type: String, required: false},
	purchase_type: {type: String, required: false},
	product_color: {type: String, required: false},
	purchase_price: {type: String, required: false},
}, {timestamps: true});

module.exports = mongoose.model("OrderChild", OrderChildSchema);