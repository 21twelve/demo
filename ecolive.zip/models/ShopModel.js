var mongoose = require("mongoose");

var Schema = mongoose.Schema;

var ShopSchema = new Schema({
	shopName: {type: String, required: true},
	description: {type: String, required: false},
	category: { type: Schema.ObjectId, ref: "ShopCategory", required: true },
	address: { type: String, required: false },
	latitude: { type: String, required: false },
	longitude: { type: String, required: false },
	zipCode: { type: String, required: false },
	image: { type: String},
	user: { type: Schema.ObjectId, ref: "User", required: true },
	completeStatus: {type: Boolean, default: false},
}, {timestamps: true});

module.exports = mongoose.model("Shop", ShopSchema);