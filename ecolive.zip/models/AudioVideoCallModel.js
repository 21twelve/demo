var mongoose = require("mongoose");

var Schema = mongoose.Schema;

var AudioVideoCallSchema = new Schema({
	vehicalName: {type: String, required: true},
	description: {type: String, required: false},
	category: { type: Schema.ObjectId, ref: "Vehical", required: false },
	address: { type: String, required: false },
	latitude: { type: String, required: false },
	longitude: { type: String, required: false },
	zipCode: { type: String, required: false },
	image: { type: String},
	user: { type: Schema.ObjectId, ref: "User", required: true },
}, {timestamps: true});

module.exports = mongoose.model("AudioVideoCall", AudioVideoCallSchema);