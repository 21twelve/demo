var mongoose = require("mongoose");

var Schema = mongoose.Schema;

var TransactionSchema = new Schema({
	transaction_id: {type: String,required: true},
	trnsaction_from: {type: Schema.ObjectId, ref: "User", required: false},
	trnsaction_to: {type: Schema.ObjectId, ref: "User", required: false},
	order: {type: Schema.ObjectId, ref: "Orders", required: false},
	transaction_type: {type: String, required: false}, //1.order 2.credit_in_wallet 3. wallet_to_wallet 4. wallet_to_bank 5. bank_to_bank 5. bank_to_wallet 6.refund 
	amount: {type: String, required: false},
	paymentType: { type: String, required: false }, // 1.Credit cart 2. Debitcart 3.Wallet
	paymentStatus: { type: String, required: false }, // 1.Pending 2.Progress 3.Completed 
	status:{ type: String},
	transaction_details:{type: [{}], required: false }
}, {timestamps: true});

module.exports = mongoose.model("Transaction", TransactionSchema);