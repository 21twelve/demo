var mongoose = require("mongoose");

var Schema = mongoose.Schema;

var OrderSchema = new Schema({
	transaction_id: {type: String,required: true},
	trnsaction_from: {type: Schema.ObjectId, ref: "User", required: false},
	trnsaction_to: {type: Schema.ObjectId, ref: "User", required: false},
	order: {type: Schema.ObjectId, ref: "Orders", required: false},
	transaction_type: {type: String, required: false},
	transaction_type: {type: String, required: false},
	amount: {type: String, required: false},
	paymentType: { type: String, required: false }, // 1.COD 2.Wallat 3.Bank 4.UPI
	paymentStatus: { type: String, required: false }, // 1.Pending 2.Completed 
	status:{ type: String},
}, {timestamps: true});

module.exports = mongoose.model("Orders", OrderSchema);