var mongoose = require("mongoose");

var Schema = mongoose.Schema;

var CartSchema = new Schema({
	user: { type: Schema.ObjectId, ref: "User", required: true },
	shop_id: { type: Schema.ObjectId, ref: "Shop", required: true },
	product_id: { type: Schema.ObjectId, ref: "Products", required: false },
	qty: { type: String },
	product_color: { type: String },
	purchase_type: { type: String },
	status:{ type: String},
}, {timestamps: true});

module.exports = mongoose.model("Cart", CartSchema);