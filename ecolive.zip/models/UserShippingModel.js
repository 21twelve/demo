var mongoose = require("mongoose");
var Schema = mongoose.Schema;

var UserShippingSchema = new mongoose.Schema({
	user: { type: Schema.ObjectId, ref: "User", required: true },
	userName: {type: String, required: true},
	userContact: {type: String, required: false},
	userPincode: {type: String, required: false},
	userAddresssLine1: {type: String, required: false},
	userAddresssLine2: {type: String, required: false},
	city: {type: String, required: false}, //shop,custmer,rider
	state: {type: String, required: false},
	country: {type: String, required: false},
	addressType: {type: String, required: false,},
	isDefaultAddress: {type: Boolean, required: false, default: 0},
}, {timestamps: true});

// Virtual for user's full name
// UserSchema
// 	.virtual("fullName")
// 	.get(function () {
// 		return this.firstName + " " + this.lastName;
// 	});

module.exports = mongoose.model("UserShipping", UserShippingSchema);