var mongoose = require("mongoose");

var Schema = mongoose.Schema;

var ReviewSchema = new Schema({
	title: {type: String, required: true},
	description: {type: String, required: true},
	rating: {type: String, required: true},
	user: { type: Schema.ObjectId, ref: "User", required: false },
}, {timestamps: true});


module.exports = mongoose.model("Review", ReviewSchema);