var mongoose = require("mongoose");

var Schema = mongoose.Schema;

var SubCategorySchema = new Schema({
	name: {type: String, required: true},
	category: { type: Schema.ObjectId, ref: "SubCategory", required: false },
	description: {type: String, required: false},
	image: { type: String},
}, {timestamps: true});

module.exports = mongoose.model("SubCategory", SubCategorySchema);