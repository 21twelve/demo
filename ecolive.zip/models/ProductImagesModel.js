var mongoose = require("mongoose");

var Schema = mongoose.Schema;

var ProductImageSchema = new Schema({
	name: { type: String, required: false},
    image: { type: String, required: true},
    description: {type: String},
	size: { type: String},
    product: { type: Schema.ObjectId, ref: "Product", required: true },
}, {timestamps: true});

module.exports = mongoose.model("ProductImage", ProductImageSchema);