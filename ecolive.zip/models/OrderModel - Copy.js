var mongoose = require("mongoose");

var Schema = mongoose.Schema;

var OrderSchema = new Schema({
	shop_id: { type: Schema.ObjectId, ref: "Shop", required: true },
	product_id: { type: Schema.ObjectId, ref: "Product", required: true },
	user: {type: String, required: false},
	userType: {type: String, required: true}, // Registered or Guest
	product_price:{type: String, required: true},
	description: {type: String, required: true},
	shipping_adr_id: { type: String, required: false },
	address: { type: String, required: false },
	latitude: { type: String, required: false },
	longitude: { type: String, required: false },
	zipCode: { type: String, required: false },
	contactNo: { type: String, required: false },
	orderStatus: { type: String, required: false }, // 1.Placed 2.Prepared 3. Booking Arranged 4.In Transit 5.Arrived at Destination 6.Out of delivery  7.Delivered 
	paymentType: { type: String, required: false }, // 1.COD 2.Wallat 3.Bank 4.UPI
	paymentStatus: { type: String, required: false }, // 1.Pending 2.Completed 
	status:{ type: String},
	user: { type: Schema.ObjectId, ref: "User", required: true },
}, {timestamps: true});

module.exports = mongoose.model("Orders", OrderSchema);