var mongoose = require("mongoose");

var Schema = mongoose.Schema;

var ProductSchema = new Schema({
	name: { type: String, required: true},
    description: {type: String},
	productImage: { type: String},
    shop: { type: Schema.ObjectId, ref: "Shop", required: true },
    category: { type: Schema.ObjectId, ref: "Category", required: true },
    subcategory: { type: Schema.ObjectId, ref: "Subcategory", required: true },
    qty: { type: Number, required:false, default: 0 },
    live_price: { type: Number, required:false, default: 0 },
    online_price: { type: Number, required:false, default: 0 },
    live_delvery: { type: Boolean, required:false, default: false },
    online_delvery: { type: Boolean, required:false, default: false },
    colors: { type : {}},
}, {timestamps: true});

module.exports = mongoose.model("Product", ProductSchema);