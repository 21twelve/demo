var mongoose = require("mongoose");

var Schema = mongoose.Schema;

var ColorSchema = new Schema({
    colorName: { type: String, required: true},
    colorCode: { type: String, required: true},
    productId: { type: Schema.ObjectId, required: true}
}, {timestamps: true});

module.exports = mongoose.model("Color", ColorSchema);