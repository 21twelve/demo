var mongoose = require("mongoose");

var Schema = mongoose.Schema;

var FavoriteSchema = new Schema({
	userId: {type: Schema.ObjectId, ref: "User", required: true },
	productId: {type: Schema.ObjectId, ref: "Product", required: true},
	description: {type: String, required: false},
}, {timestamps: true});

module.exports = mongoose.model("Favorite", FavoriteSchema);