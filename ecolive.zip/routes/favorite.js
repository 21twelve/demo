var express = require("express");
const FavoriteController = require("../controllers/FavoriteController");
var router = express.Router();

router.post("/getFavoriteList", FavoriteController.favoriteList);
router.post("/",FavoriteController.favoriteStore);
router.delete("/:id", FavoriteController.favoriteDelete);

module.exports = router;