var express = require("express");
const ReviewController = require("../controllers/ReviewController");

var router = express.Router();

router.get("/", ReviewController.reviewList);
router.get("/:id", ReviewController.reviewDetail);
router.post("/", ReviewController.reviewAdd);
router.put("/:id", ReviewController.reviewUpdate);
router.delete("/:id", ReviewController.reviewDelete);

module.exports = router;