var express = require("express");
var utilityRouter = require("./utility");
var authRouter = require("./auth");
var shopRouter = require("./shop");
var orderRouter = require("./order");
var ShopCategoryRouter = require("./shopCategory");
var VehicalCategoryRouter = require("./vehicalCategory");
var CategoryRouter = require("./category");
var SubCategoryRouter = require("./subCategory");
var VehicalRouter = require("./vehical");
var productRouter = require("./product");
var cartRouter = require("./cart");
var orderRouter = require("./order");
var favoriteRouter = require("./favorite");
var audioVideoCallRouter = require("./audioVideoCall");


var app = express();
app.use("/utility/", utilityRouter);
app.use("/auth/", authRouter);
app.use("/shop/", shopRouter);
app.use("/order/", orderRouter);
app.use("/shopCategory/", ShopCategoryRouter);
app.use("/vehicalCategory/", VehicalCategoryRouter);
app.use("/category/", CategoryRouter);
app.use("/subCategory/", SubCategoryRouter);
app.use("/vehical/", VehicalRouter);
app.use("/product/", productRouter);
app.use("/addProduct/", productRouter);
app.use("/editProduct/", productRouter);
app.use("/productList/", productRouter);
app.use("/favorite/", favoriteRouter);
app.use("/audioVideoCall/", audioVideoCallRouter);
app.use("/cart/", cartRouter);
app.use("/order/", orderRouter);

module.exports = app;
