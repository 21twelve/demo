var express = require("express");
const CartController = require("../controllers/CartController");

var router = express.Router();

router.get("/", CartController.cartList);
//router.get("/:id", CartController.cartDetail);
router.post("/", CartController.cartStore);
router.post("/:id", CartController.cartUpdate);
router.delete("/:id", CartController.cartDelete);
router.delete("/", CartController.cartDeleteAll);


module.exports = router;