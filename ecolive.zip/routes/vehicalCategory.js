var express = require("express");
const VehicalCategoryController = require("../controllers/VehicalCategoryController");

var router = express.Router();

router.get("/", VehicalCategoryController.vehicalCategoryList);
router.post("/", VehicalCategoryController.vehicalCategoryStore);
router.put("/:id", VehicalCategoryController.vehicalCategoryUpdate);
router.delete("/:id", VehicalCategoryController.vehicalCategoryDelete);

module.exports = router;