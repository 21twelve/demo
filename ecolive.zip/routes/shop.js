var express = require("express");
const ShopController = require("../controllers/ShopController");
const multer = require("multer");
var router = express.Router();

const storage = multer.diskStorage({
    destination: (req, file, cb) => {
      cb(null, "./uploads");
    },
    filename: (req, file, cb) => {
      cb(null, Date.now()+'-'+file.originalname);
    },
  });
  
  const fileFilter = (req, file, cb) => {
    if (file.mimetype === "image/jpeg" || file.mimetype === "image/png") {
      cb(null, true);
    } else {
      cb(null, false);
    }
  };
  
  const upload = multer({
    storage: storage,
    limit: {
      fileSize: 1024 * 1024 * 5,
    },
    fileFilter: fileFilter,
  });


router.get("/", ShopController.shopList);
router.get("/:id", ShopController.shopDetail);
router.post("/",upload.single("image"),ShopController.shopStore);
//router.post("/", ShopController.shopStore);
router.post("/:id",upload.single("image"), ShopController.shopUpdate);
router.delete("/:id", ShopController.shopDelete);

module.exports = router;