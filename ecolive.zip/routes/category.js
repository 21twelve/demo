var express = require("express");
const fs = require('fs');
const CategoryController = require("../controllers/CategoryController");
const multer = require("multer");

var router = express.Router();


const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    console.log(req.params.id);
    const { id } = req.params.id;
    const path = `./uploads/`+req.params.id+'/category'
    fs.mkdirSync(path, { recursive: true })
    return cb(null, path)
  },
    // destination: (req, file, cb) => {
    //   console.log(req.headers.authorization);
    //   cb(null, "./uploads");
    // },
    filename: (req, file, cb) => {
      //cb(null, new Date().toISOString() + file.originalname);
	  cb(null, Date.now()+'-'+file.originalname);
    },
  });
  
  const fileFilter = (req, file, cb) => {
    
    if (file.mimetype === "image/jpeg" || file.mimetype === "image/png" || file.mimetype === "image/gif") {
      cb(null, true);
    } else {
      cb(null, false);
    }
  };
  
  const upload = multer({
    storage: storage,
    limit: {
      fileSize: 1024 * 1024 * 5,
    },
    fileFilter: fileFilter,
  });

router.get("/", CategoryController.categoryList);
router.get("/:id", CategoryController.categoryDetail);
router.post("/",upload.single("proCatImage"),CategoryController.categoryStore);
router.put("/:id",upload.single("proCatImage"),CategoryController.categoryUpdate);
router.delete("/:id", CategoryController.categoryDelete);

module.exports = router;