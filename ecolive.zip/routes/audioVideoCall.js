var express = require("express");
const AudioVidioCallController = require("../controllers/AudioVideoCallController");

var router = express.Router();

router.get("/audioToken", AudioVidioCallController.accessToken);
router.post("/audioToken", AudioVidioCallController.accessToken);

router.get("/videoToken", AudioVidioCallController.accessTokenVideoCall);
router.post("/videoToken", AudioVidioCallController.accessTokenVideoCall);

// router.get("/:id", AudioVidioCallController.vehicalDetail);

module.exports = router;