var express = require("express");
const ShopCategoryController = require("../controllers/ShopCategoryController");

var router = express.Router();

router.get("/", ShopCategoryController.shopCategoryList);
router.post("/", ShopCategoryController.shopCategoryStore);
router.put("/:id", ShopCategoryController.shopCategoryUpdate);
router.delete("/:id", ShopCategoryController.shopCategoryDelete);

module.exports = router;