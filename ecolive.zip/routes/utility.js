var express = require("express");
const UtilityController = require("../controllers/UtilityController");

var router = express.Router();

router.get("/", UtilityController.utilityList);

module.exports = router;