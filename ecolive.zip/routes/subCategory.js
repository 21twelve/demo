var express = require("express");
const fs = require('fs');
const SubCategoryController = require("../controllers/SubCategoryController");
const multer = require("multer");

var router = express.Router();
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, "./uploads");
  },
  // destination: (req, file, cb) => {
  //   console.log(req.params.id);
  //   const { id } = req.params.id;
  //   const path = `./uploads/`+req.params.id+'/subcategory'
  //   fs.mkdirSync(path, { recursive: true })
  //   return cb(null, path)
  // },
    filename: (req, file, cb) => {
      //cb(null, new Date().toISOString() + file.originalname);
	  cb(null, Date.now()+'-'+file.originalname);
    },
  });
  
  const fileFilter = (req, file, cb) => {
    
    if (file.mimetype === "image/jpeg" || file.mimetype === "image/png") {
      cb(null, true);
    } else {
      cb(null, false);
    }
  };
  
  const upload = multer({
    storage: storage,
    limit: {
      fileSize: 1024 * 1024 * 5,
    },
    fileFilter: fileFilter,
  });

router.get("/:id", SubCategoryController.subCategoryList);
router.get("/:id", SubCategoryController.subCategoryDetail);
router.post("/",upload.single("proSubCatImage"),SubCategoryController.subCategoryStore);
router.put("/:id",upload.single("proSubCatImage"), SubCategoryController.subCategoryUpdate);
router.delete("/:id", SubCategoryController.subCategoryDelete);

module.exports = router;