var express = require("express");
const ProductController = require("../controllers/ProductController");
const multer = require("multer");
var router = express.Router();


const storage = multer.diskStorage({
    destination: (req, file, cb) => {
      cb(null, `./uploads`);
    },
    filename: (req, file, cb) => {
      cb(null, Date.now()+'-'+file.originalname);
    },
  });
  
  const fileFilter = (req, file, cb) => {
    
    if (file.mimetype === "image/jpeg" || file.mimetype === "image/png") {
      cb(null, true);
    } else {
      cb(null, false);
    }
  };
  
  const upload = multer({
    storage: storage,
    limit: {
      fileSize: 1024 * 1024 * 5,
    },
    fileFilter: fileFilter,
  });

  
router.post("/search", ProductController.productSearch);  
router.post("/search_demo", ProductController.productSearch_demo);  
router.get("/list/:id", ProductController.productList);
router.get("/:id", ProductController.productDetail);
router.post("/",upload.array("productImage"),ProductController.productStore);
router.post("/:id",upload.array("productImage"),ProductController.productUpdate);
router.delete("/:id", ProductController.productDelete);

module.exports = router;