const Stripe = require('stripe');
const stripe = Stripe('sk_test_51JDSCaICa4fFFXRVFXTz8l8383xMrh13Frl0datQWy3RlgvbZv8KsiuWmlBVAYrk406XBTEMpMx30Ewq6hSBkkSX00f3hTrNTn');

exports.createToken = async function () {
	console.log('aaaaaaaaaaaa');
	const token = await stripe.tokens.create({
		card: {
			number: '4242424242424242',
			exp_month: 9,
			exp_year: 2022,
			cvc: '314',
		},
	});
	return token;
};

exports.makePayment = async function (token) {
	const charges = await stripe.charges.create({
		amount:100, 
		currency: "usd",
		source: token.id,
	});
	return charges;
};