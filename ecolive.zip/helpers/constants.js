
exports.constants = {
	admin: {
		name: "admin",
		email: "admin@admin.com"
	},
	confirmEmails: {
		from : "no-reply@test-app.com"
	},
	urlPath: {
		base :'http://localhost:3000/',
		port : "3000",
		upload_dir : "uploads",
		upload_url:"http://localhost:3000/uploads/",
		noimage:"http://localhost:3000/uploads/noimage.jpg",
		media : "uploads",
	}
};