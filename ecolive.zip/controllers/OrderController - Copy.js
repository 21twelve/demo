const Order = require("../models/OrderModel");
const Product = require("../models/ProductModel");
const Cateogry = require("../models/CategoryModel");
const SubCategory = require("../models/SubCategoryModel");
const Shop = require("../models/ShopModel");
const { body,validationResult } = require("express-validator");
const { sanitizeBody } = require("express-validator");
const apiResponse = require("../helpers/apiResponse");
const auth = require("../middlewares/jwt");
var mongoose = require("mongoose");
mongoose.set("useFindAndModify", false);
const { constants } = require("../helpers/constants");

// var Publishable_Key = 'Your_Publishable_Key'
// var Secret_Key = 'Your_Secret_Key'
// const stripe = require('stripe')(Secret_Key)


const Stripe = require('stripe');
const stripe = Stripe('sk_test_51JDSCaICa4fFFXRVFXTz8l8383xMrh13Frl0datQWy3RlgvbZv8KsiuWmlBVAYrk406XBTEMpMx30Ewq6hSBkkSX00f3hTrNTn');


// Order Schema
function OrderData(data) {
	this.id = data._id;
	this.user = data.user;
	this.shop = data.shopId;
	this.product = data.productId;
	this.userType = data.userType;
	this.description = data.description;
	this.address = data.address;
	this.latitude = data.latitude;
	this.longitude = data.longitude;
	this.zipCode = data.zipCode;
	this.contactNo = data.contactNo;
	this.orderStatus = data.orderStatus;
	this.updatedAt = data.updatedAt;
	this.createdAt = data.createdAt;
}

/**
 * Order List.
 * 
 * @returns {Object}
 */
exports.orderList = [
	auth,
	function (req, res) {
		try {
			let user_id = mongoose.Types.ObjectId(req.user._id);
			console.log(user_id);
			const order_qry = [
			{
				$lookup:{
					from: 'products', 
					localField:'product_id', 
					foreignField:'_id',
					as:'products'
				}
			},
			{$unwind: '$products'},
			{
				$lookup:{
					from: 'productimages', 
					localField:'products._id', 
					foreignField:'product',
					as:'images'
				},
			},
			{$unwind: '$images'},
			{ 
				"$group": {
					"_id": "$_id",
					"user": { "$first": "$user" },
					"shop_id": { "$first": "$shop_id" },
					"product_id": { "$first": "$product_id" },
					"userType": { "$first": "$userType" },
					"address": { "$first": "$address" },
					"latitude": { "$first": "$latitude" },
					"longitude": { "$first": "$longitude" },
					"zipCode": { "$first": "$zipCode" },
					"contactNo": { "$first": "$contactNo" },
					"description": { "$first": "$description" },
					"paymentType": { "$first": "$paymentType" },
					"paymentStatus": { "$first": "$paymentStatus" },
					"orderStatus": { "$first": "$orderStatus" },
					"createdAt": { "$first": "$createdAt" },
					"updatedAt": { "$first": "$updatedAt" },
					"products": { "$first": "$products" },
					"images": { "$first": "$images" },     
				}
			},
				{
					$project: { 
						user:1,
						shop_id:1,
						product_id:1,
						userType:1,
						address:1,
						latitude:1,
						longitude:1,
						zipCode:1,
						contactNo:1,
						description:1,
						paymentType:1,
						paymentStatus:1,
						orderStatus:1,
						createdAt:1,
						updatedAt:1,
						product_name : "$products.name",
						live_price : "$products.live_price",
						online_price : "$products.online_price",
						product_image: {
							$concat:
							[
							// {$cond:[{$eq:['$image', null]}, "", constants.urlPath.base] },
							{$cond:[{$eq:[{$ifNull:["$images.image",constants.urlPath.base]},constants.urlPath.base]},"",constants.urlPath.base]},
							{$ifNull:["$images.image",""]}
							]
						},
					//	image:{$concat:[constants.urlPath.base]}
					}
				},
			{ $facet : {payload : [ { $skip: 0 }, {$limit: 100 } ] } }
			]
			if (user_id) {
				order_qry.unshift({ $match: {user: user_id} });
			}
			Order.aggregate(order_qry).exec((err, result)=>{
				if (err) {
					//console.log("error" ,err)
					return apiResponse.ErrorResponse(res, err);
				}
				if (result) {
					//console.log(result);
					return apiResponse.successResponseWithData(res,"Opration successfully.", result[0].payload);

				}
			});
		} catch (err) {
			//throw error in json response with status 500. 
			return apiResponse.ErrorResponse(res, err);
		}
	}
];

/**
 * Shop Detail.
 * 
 * @param {string} id
 * 
 * @returns {Object}
 */
exports.orderDetail = [
	auth,
	function (req, res) {
		if(!mongoose.Types.ObjectId.isValid(req.params.id)){
			return apiResponse.successResponseWithData(res, "Operation success111", {});
		}
		try {
			Orders.findOne({_id: req.params.id,user: req.user._id},"_id shopName description category address latitude longitude zipCode createdAt").then((shop)=>{                
				if(shop !== null){
					let shopData = new ShopData(shop);
					return apiResponse.successResponseWithData(res, "Operation success11", shopData);
				}else{
					return apiResponse.successResponseWithData(res, "Operation success11", {});
				}
			});
		} catch (err) {
			//throw error in json response with status 500. 
			return apiResponse.ErrorResponse(res, err);
		}
	}
];

/**
 * Shop store.
 * 
 * @param {string}  shopName 
 * @param {string}  category
 * @param {string}  address
 * @param {string}  latitude
 * @param {string}  longitude
 * @param {string} 	zipCode
 * @param {string} 	description
 * @returns {Object}
 */
exports.orderStore = [
	auth,
	body("userType", "User type must not be empty.").isLength({ min: 1 }).trim(),
	body("paymentType", "Payment Type type must not be empty.").isLength({ min: 1 }).trim(),
	body("paymentStatus", "Payment Status type must not be empty.").isLength({ min: 1 }).trim(),
	body("shop_id", "Shop must not be empty.").isLength({ min: 1 }).trim(),
	body("product_id", "Product must not be empty.").isLength({ min: 1 }).trim(),
	body("address", "address must not be empty.").isLength({ min: 1 }).trim(),
	body("zipCode", "zipCode must not be empty.").isLength({ min: 1 }).trim(),
	body("latitude", "latitude must not be empty.").isLength({ min: 1 }).trim(),
	body("longitude", "longitude must not be empty.").isLength({ min: 1 }).trim(),
	body("description", "Description must not be empty.").isLength({ min: 1 }).trim(),
	sanitizeBody("*").escape(),
	(req, res) => {
		try {
			
			const errors = validationResult(req);
			var order = new Order(
				{ 	
					shop_id: req.body.shop_id,
					product_id: req.body.product_id,
					product_price:req.body.product_price,
					user: req.user,
					userType: req.body.userType,
					address: req.body.address,
					latitude: req.body.latitude,
					longitude: req.body.longitude,
					zipCode : req.body.zipCode,
					contactNo: req.body.contactNo,
					description: req.body.description,
					paymentType:req.body.paymentType,
					paymentStatus:req.body.paymentStatus,
					orderStatus: 'Placed',
				});
				
			if (!errors.isEmpty()) {
				return apiResponse.validationErrorWithData(res, "Validation Error.", errors.array());
			}
			else {
				//Save order.
				order.save(function (err) {
					if (err) { return apiResponse.ErrorResponse(res, err); }
					//let orderData = new OrderData(order);

					///////// Stripe payment start ///////////
					
					const promiseA = new Promise(function(resolve, reject) {
						if(typeof req.body.product_price != 'undefined' && req.body.product_price > 0 && typeof req.body.stripe_token != 'undefined' && req.body.stripe_token != '')
						{
							console.log('111111111111');
							var charge = stripe.charges.create({
								amount: req.body.product_price, // amount in cents, again
								currency: "usd",
								source: req.body.stripe_token,
								metadata: {'order_id': order._id}
								
							}, function(err, charge) {
								if (err && err.type === 'StripeCardError') {
									console.log(JSON.stringify(err, null, 2));
									resolve(false);
									console.log('false---------');
								}
								console.log('trueeeeee---------',charge);
								resolve(charge);
								//res.send("completed payment!")
							});
							
							// stripe.charges.create({
							// 	amount: req.body.product_price,
							// 	currency: "usd",
							// 	source: req.body.stripe_token, // obtained with Stripe.js
							// 	metadata: {'order_id': order._id}
							// });
						}
					});
					///////// Stripe payment end ///////////
					promiseA.then(value => {
						console.log('Stripe- Response--------------------------',value);

						let order_id = mongoose.Types.ObjectId(order._id);
						
						const order_qry = [
							// { $match: {category: cart_id } },
						{
							$lookup:{
								from: 'products', 
								localField:'product_id', 
								foreignField:'_id',
								as:'products'
							}
						},
						{$unwind: '$products'},
						{
							$lookup:{
								from: 'productimages', 
								localField:'products._id', 
								foreignField:'product',
								as:'images'
							},
						},
						{$unwind: '$images'},
						{ 
							"$group": {
								"_id": "$_id",
								"user": { "$first": "$user" },
								"shop_id": { "$first": "$shop_id" },
								"product_id": { "$first": "$product_id" },
								"userType": { "$first": "$userType" },
								"address": { "$first": "$address" },
								"latitude": { "$first": "$latitude" },
								"longitude": { "$first": "$longitude" },
								"zipCode": { "$first": "$zipCode" },
								"contactNo": { "$first": "$contactNo" },
								"description": { "$first": "$description" },
								"paymentType": { "$first": "$paymentType" },
								"paymentStatus": { "$first": "$paymentStatus" },
								"createdAt": { "$first": "$createdAt" },
								"updatedAt": { "$first": "$updatedAt" },
								"products": { "$first": "$products" },
								"images": { "$first": "$images" },     
							}
						},
							{
								$project: { 
									user:1,
									shop_id:1,
									product_id:1,
									userType:1,
									address:1,
									latitude:1,
									longitude:1,
									zipCode:1,
									contactNo:1,
									description:1,
									paymentType:1,
									paymentStatus:1,
									createdAt:1,
									updatedAt:1,
									product_name : "$products.name",
									live_price : "$products.live_price",
									online_price : "$products.online_price",
									product_image: {
										$concat:
										[
										// {$cond:[{$eq:['$image', null]}, "", constants.urlPath.base] },
										{$cond:[{$eq:[{$ifNull:["$images.image",constants.urlPath.base]},constants.urlPath.base]},"",constants.urlPath.base]},
										{$ifNull:["$images.image",""]}
										]
									},
								//	image:{$concat:[constants.urlPath.base]}
								}
							},
						{ $facet : {payload : [ { $skip: 0 }, {$limit: 100 } ] } }
						]
						if (order_id) {
							order_qry.unshift({ $match: {_id: order_id } });
						}
						Order.aggregate(order_qry).exec((err, result)=>{
							if (err) {
								//console.log("error" ,err)
								return apiResponse.ErrorResponse(res, err);
							}
							if (result) {
								//console.log(result);
								return apiResponse.successResponseWithData(res,"Your order successfully.", result[0].payload[0]);

							}
						});
					}, reason => {
						return apiResponse.successResponseWithData(res,"Order Success.", productData);
					  });
					//return apiResponse.successResponseWithData(res,"Order add Success.", orderData);
				});
			}
		} catch (err) {
			//throw error in json response with status 500. 
			return apiResponse.ErrorResponse(res, err);
		}
	}
];

/**
 * Order update.
 * 
 * @param {string}      category
 * @param {string}      zipCode 
 * @param {string}      description
 * @param {string}      address
 * @param {string}      latitude
 * @param {string}      longitude
 
 * 
 * @returns {Object}
/**
 * Cart update.
 * 
 * @param {string}  shopId 
 * @param {string}  productId
 * @param {string}  userId
 * @param {string}  qty
 * @returns {Object}
 
 * 
 * @returns {Object}
 */
 exports.orderUpdate = [
	auth,
	sanitizeBody("*").escape(),
	(req, res) => {
		try {
			const errors = validationResult(req);

			var order = new Order(
				{ 
					_id:req.params.id
				});
			if(req.body.paymentStatus != ''  && req.body.orderStatus != '')
			{
				order.paymentStatus = req.body.paymentStatus;
				order.orderStatus = req.body.orderStatus;
			}
			else if(req.body.paymentStatus != '')
			{
				order.paymentStatus = req.body.paymentStatus;
			}
			else if(req.body.orderStatus != '')
			{
				order.orderStatus = req.body.orderStatus;
			}
			

			if (!errors.isEmpty()) {
				return apiResponse.validationErrorWithData(res, "Validation Error.", errors.array());
			}
			else {
				if(!mongoose.Types.ObjectId.isValid(req.params.id)){
					return apiResponse.validationErrorWithData(res, "Invalid Error.", "Invalid ID");
				}else{
					Order.findById(req.params.id, function (err, foundOrder) {
						if(foundOrder === null){
							return apiResponse.notFoundResponse(res,"Order not exists with this id");
						}else{
							//Check authorized user
							if(foundOrder.user.toString() !== req.user._id){
								return apiResponse.unauthorizedResponse(res, "You are not authorized to do this operation.");
							}else{
								//update order.
								Order.findByIdAndUpdate(req.params.id, order, {},function (err) {
									if (err) { 
										return apiResponse.ErrorResponse(res, err); 
									}else{
										let order_id = mongoose.Types.ObjectId(req.params.id);
					
										const order_qry = [
											// { $match: {category: cart_id } },
										{
											$lookup:{
												from: 'products', 
												localField:'product_id', 
												foreignField:'_id',
												as:'products'
											}
										},
										{$unwind: '$products'},
										{
											$lookup:{
												from: 'productimages', 
												localField:'products._id', 
												foreignField:'product',
												as:'images'
											},
										},
										{$unwind: '$images'},
										{ 
											"$group": {
												"_id": "$_id",
												"user": { "$first": "$user" },
												"shop_id": { "$first": "$shop_id" },
												"product_id": { "$first": "$product_id" },
												"userType": { "$first": "$userType" },
												"address": { "$first": "$address" },
												"latitude": { "$first": "$latitude" },
												"longitude": { "$first": "$longitude" },
												"zipCode": { "$first": "$zipCode" },
												"contactNo": { "$first": "$contactNo" },
												"description": { "$first": "$description" },
												"paymentType": { "$first": "$paymentType" },
												"paymentStatus": { "$first": "$paymentStatus" },
												"orderStatus": { "$first": "$orderStatus" },
												"createdAt": { "$first": "$createdAt" },
												"updatedAt": { "$first": "$updatedAt" },
												"products": { "$first": "$products" },
												"images": { "$first": "$images" },     
											}
										},
											{
												$project: { 
													user:1,
													shop_id:1,
													product_id:1,
													userType:1,
													address:1,
													latitude:1,
													longitude:1,
													zipCode:1,
													contactNo:1,
													description:1,
													paymentType:1,
													paymentStatus:1,
													orderStatus:1,
													createdAt:1,
													updatedAt:1,
													product_name : "$products.name",
													live_price : "$products.live_price",
													online_price : "$products.online_price",
													product_image: {
														$concat:
														[
														// {$cond:[{$eq:['$image', null]}, "", constants.urlPath.base] },
														{$cond:[{$eq:[{$ifNull:["$images.image",constants.urlPath.base]},constants.urlPath.base]},"",constants.urlPath.base]},
														{$ifNull:["$images.image",""]}
														]
													},
												//	image:{$concat:[constants.urlPath.base]}
												}
											},
										{ $facet : {payload : [ { $skip: 0 }, {$limit: 100 } ] } }
										]
										if (order_id) {
											order_qry.unshift({ $match: {_id: order_id } });
										}
										Order.aggregate(order_qry).exec((err, result)=>{
											if (err) {
												//console.log("error" ,err)
												return apiResponse.ErrorResponse(res, err);
											}
											if (result) {
												//console.log(result);
												return apiResponse.successResponseWithData(res,"Order updated successfully.", result[0].payload[0]);
					
											}
										});
									}
								});
							}
						}
					});
				}
			}
		} catch (err) {
			//throw error in json response with status 500. 
			return apiResponse.ErrorResponse(res, err);
		}
	}
];
