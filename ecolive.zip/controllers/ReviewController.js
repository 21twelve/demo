const Review = require("../models/ReviewModel");
const { body,validationResult } = require("express-validator");
const { sanitizeBody } = require("express-validator");
const apiResponse = require("../helpers/apiResponse");
const auth = require("../middlewares/jwt");
var mongoose = require("mongoose");
mongoose.set("useFindAndModify", false);


// Review Schema
function ReviewData(data) {
	this.id = data._id;
	this.title = data.title;
	this.description = data.description;
	this.rating = data.rating;
	this.createdAt = data.createdAt;
}

/**
 * Review List.
 * 
 * @returns {Object}
 */
exports.reviewList = [
	auth,
	function (req, res) {
		//try {
			Review.find({user: req.user._id},"_id title description rating createdAt").then((reviews)=>{
				if(reviews.length > 0){
					return apiResponse.successResponseWithData(res, "Operation success", reviews);
				}else{
					return apiResponse.successResponseWithData(res, "Operation success", []);
				}
			});
		// } catch (err) {
		// 	//throw error in json response with status 500. 
		// 	return apiResponse.ErrorResponse(res, err);
		// }
	}
];

/**
 * Review Detail.
 * 
 * @param {string}      id
 * 
 * @returns {Object}
 */
exports.reviewDetail = [
	auth,
	function (req, res) {
		if(!mongoose.Types.ObjectId.isValid(req.params.id)){
			return apiResponse.successResponseWithData(res, "Operation success", {});
		}
		//try {
			Review.findOne({_id: req.params.id,user: req.user._id},"_id title description rating createdAt").then((review)=>{                
				if(review !== null){
					let reviewData = new ReviewData(review);
					return apiResponse.successResponseWithData(res, "Operation success", reviewData);
				}else{
					return apiResponse.successResponseWithData(res, "Operation success", {});
				}
			});
		// } catch (err) {
		// 	//throw error in json response with status 500. 
		// 	return apiResponse.ErrorResponse(res, err);
		// }
	}
];

/**
 * Review store.
 * 
 * @param {string}      title 
 * @param {string}      description
 * @param {string}      rating
 *
 * 
 * @returns {Object}
 */
exports.reviewAdd = [
	auth,
	body("title", "Title must not be empty.").isLength({ min: 1 }).trim().custom((value,{req}) => {
		return Review.findOne({title : value,user: req.user._id}).then(review => {
			if (review) {
				return Promise.reject("Review already exist with this name");
			}
		});
	}),
	body("description", "Description must not be empty.").isLength({ min: 1 }).trim(),
	body("rating", "rating must not be empty").isLength({ min: 1 }).trim(),
	
	sanitizeBody("*").escape(),
	(req, res) => {
		//try {
			const errors = validationResult(req);
			var review = new Review(
				{ title: req.body.title,
					user: req.user,
					description: req.body.description,
					rating: req.body.rating
				});

			if (!errors.isEmpty()) {
				return apiResponse.validationErrorWithData(res, "Validation Error.", errors.array());
			}
			else {
				//Save review.
				review.save(function (err) {
					if (err) { return apiResponse.ErrorResponse(res, err); }
					let reviewData = new ReviewData(review);
					return apiResponse.successResponseWithData(res,"Review add Success.", reviewData);
				});
			}
		// } catch (err) {
		// 	//throw error in json response with status 500. 
		// 	return apiResponse.ErrorResponse(res, err);
		// }
	}
];

/**
 * Review update.
 * 
 * @param {string}      title 
 * @param {string}      description
 * @param {string}      rating
 * 
 * @returns {Object}
 */
exports.reviewUpdate = [
	auth,
	body("title", "Title must not be empty.").isLength({ min: 1 }).trim(),
	body("description", "Description must not be empty.").isLength({ min: 1 }).trim(),
	body("rating", "rating must not be empty").isLength({ min: 1 }).trim().custom((value,{req}) => {
		return Review.findOne({rating : value,user: req.user._id, _id: { "$ne": req.params.id }}).then(review => {
			if (review) {
				return Promise.reject("Review already exist with this price no.");
			}
		});
	}),

	sanitizeBody("*").escape(),
	(req, res) => {
		//try {
			console.log({ title: req.body.title,
				description: req.body.description,
				rating: req.body.rating,
				_id:req.params.id
			})
			const errors = validationResult(req);
			var review = new Review(
				{ title: req.body.title,
					description: req.body.description,
					rating: req.body.rating,
					_id:req.params.id
				});
			
				//console.log(review);

			if (!errors.isEmpty()) {
				return apiResponse.validationErrorWithData(res, "Validation Error.", errors.array());
			}
			else {
				if(!mongoose.Types.ObjectId.isValid(req.params.id)){
					return apiResponse.validationErrorWithData(res, "Invalid Error.", "Invalid ID");
				}else{
					Review.findById(req.params.id, function (err, foundReview) {
						if(foundReview === null){
							return apiResponse.notFoundResponse(res,"Product not exists with this id");
						}else{
							//Check authorized user
							if(foundReview.user.toString() !== req.user._id){
								return apiResponse.unauthorizedResponse(res, "You are not authorized to do this operation.");
							}else{
								//update review.
								Review.findByIdAndUpdate(req.params.id, review, {},function (err) {
									if (err) { 
										return apiResponse.ErrorResponse(res, err); 
									}else{
										let reviewData = new ReviewData(review);
										return apiResponse.successResponseWithData(res,"Review update Success.", reviewData);
									}
								});
							}
						}
					});
				}
			}
		// } catch (err) {
		// 	//throw error in json response with status 500. 
		// 	return apiResponse.ErrorResponse(res, err);
		// }
	}
];

/**
 * Review Delete.
 * 
 * @param {string}      id
 * 
 * @returns {Object}
 */
exports.reviewDelete = [
	auth,
	function (req, res) {
		if(!mongoose.Types.ObjectId.isValid(req.params.id)){
			return apiResponse.validationErrorWithData(res, "Invalid Error.", "Invalid ID");
		}
		//try {
			Review.findById(req.params.id, function (err, foundReview) {
				if(foundReview === null){
					return apiResponse.notFoundResponse(res,"Review not exists with this id");
				}else{
					//Check authorized user
					if(foundReview.user.toString() !== req.user._id){
						return apiResponse.unauthorizedResponse(res, "You are not authorized to do this operation.");
					}else{
						//delete Review.
						Review.findByIdAndRemove(req.params.id,function (err) {
							if (err) { 
								return apiResponse.ErrorResponse(res, err); 
							}else{
								return apiResponse.successResponse(res,"Review delete Success.");
							}
						});
					}
				}
			});
		// } catch (err) {
		// 	//throw error in json response with status 500. 
		// 	return apiResponse.ErrorResponse(res, err);
		// }
	}
];