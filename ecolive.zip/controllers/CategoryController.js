const Category = require("../models/CategoryModel");
const { body,validationResult } = require("express-validator");
const { sanitizeBody } = require("express-validator");
const apiResponse = require("../helpers/apiResponse");
const auth = require("../middlewares/jwt");
var mongoose = require("mongoose");
const { constants } = require("../helpers/constants");
mongoose.set("useFindAndModify", false);

// Category Schema
function CategoryData(data) {
	this.id = data._id;
	this.name= data.name;
	this.description = data.description;
	this.image = data.image;
	this.createdAt = data.createdAt;
}

/**
 * Category List.
 * 
 * @returns {Object}
 */
exports.categoryList = [
	auth,
	function (req, res) {
		try {
			Category.find({},"_id user name description image createdAt").then((categories)=>{
				if(categories.length > 0){

					var i = 0;
					categories.forEach(function(categories) {
					
						if(typeof categories.image === 'undefined')
						{
							categories.image = '';
						}
						else
						{
							categories.image =  constants.urlPath.base+categories.image;
							//categories[i].image = constants.urlPath.base;
							
						}
						i++;
						
					});

					//
					return apiResponse.successResponseWithData(res, "Operation success", categories);
				}else{
					return apiResponse.successResponseWithData(res, "Operation success", []);
				}
			});
		} catch (err) {
			//throw error in json response with status 500. 
			return apiResponse.ErrorResponse(res, err);
		}
	}
];

/**
 * Category Detail.
 * 
 * @param {string} id
 * 
 * @returns {Object}
 */
exports.categoryDetail = [
	auth,
	function (req, res) {
		if(!mongoose.Types.ObjectId.isValid(req.params.id)){
			return apiResponse.successResponseWithData(res, "Operation success", {});
		}
		try {
			Category.findOne({_id: req.params.id},"_id user name description category image createdAt").then((category)=>{                
				if(category !== null){
					let categoryData = new CategoryData(category);
					return apiResponse.successResponseWithData(res, "Operation success11", categoryData);
				}else{
					return apiResponse.successResponseWithData(res, "Operation success11", {});
				}
			});
		} catch (err) {
			//throw error in json response with status 500. 
			return apiResponse.ErrorResponse(res, err);
		}
	}
];

/**
 * Shop store.
 * 
 * @param {string}  name 
 * @param {string}  category
 * @param {string} 	description
 * @returns {Object}
 */
exports.categoryStore = [
	auth,
	body("catName", "categoryame must not be empty.").isLength({ min: 1 }).trim(),
	body("description", "Description must not be empty.").isLength({ min: 1 }).trim().custom((value,{req}) => {
		return Category.findOne({name : value}).then(category => {
			if (category) {
				return Promise.reject("Category already exist with this shop name.");
			}
		});
	}),
	sanitizeBody("*").escape(),
	(req, res) => {
		try {
			
			const errors = validationResult(req);
			
			var category = new Category(
				{ 	
					name: req.body.catName,
					description: req.body.description,
					image :req.file.path
				});
				
				
			if (!errors.isEmpty()) {
				return apiResponse.validationErrorWithData(res, "Validation Error.", errors.array());
			}
			else {
				//Save shop.
				category.save(function (err) {
					if (err) { return apiResponse.ErrorResponse(res, err); }
					let categoryData = new CategoryData(category);
					categoryData.image = constants.urlPath.base+categoryData.image;
					return apiResponse.successResponseWithData(res,"Category add Success.", categoryData);
				});
			}
		} catch (err) {
			//throw error in json response with status 500. 
			return apiResponse.ErrorResponse(res, err);
		}
	}
];

/**
 * Shop update.
 * 
 * @param {string}      shopName
 * @param {string}      category
 * @param {string}      zipCode 
 * @param {string}      description
 * @param {string}      address
 * @param {string}      latitude
 * @param {string}      longitude
 
 * 
 * @returns {Object}
 */
exports.categoryUpdate = [
	auth,
	body("catName", "cat name must not be empty.").isLength({ min: 1 }).trim(),
	body("description", "Description must not be empty.").isLength({ min: 1 }).trim().custom((value,{req}) => {
		return Category.findOne({name: req.params.catName,_id: { "$ne": req.params.id }}).then(vehicalCategory => {
			if (vehicalCategory) {
				console.log('req.params.id',req.params.id)
				return Promise.reject("Vehical Category already exist with this no.");
			}
		});
	}),
	sanitizeBody("*").escape(),
	(req, res) => {
		try {
		
			const errors = validationResult(req);
			var category = new Category(
				{ 
					name: req.body.catName,
					description: req.body.description,
					image :req.file.path,
					_id:req.params.id
					
				});

			if (!errors.isEmpty()) {
				return apiResponse.validationErrorWithData(res, "Validation Error.", errors.array());
			}
			else {
				if(!mongoose.Types.ObjectId.isValid(req.params.id)){
					return apiResponse.validationErrorWithData(res, "Invalid Error.", "Invalid ID");
				}else{
					Category.findById(req.params.id, function (err, foundCategory) {
						if(foundCategory === null){
							return apiResponse.notFoundResponse(res,"Shop not exists with this id");
						}else{
							//Check authorized user
							
								//update shop.
								Category.findByIdAndUpdate(req.params.id, category, {},function (err) {
									if (err) { 
										return apiResponse.ErrorResponse(res, err); 
									}else{
										let categoryData = new CategoryData(category);
										categoryData.image = constants.urlPath.base+categoryData.image;
										return apiResponse.successResponseWithData(res,"Category update Success.", categoryData);
									}
								});
							
						}
					});
				}
			}
		} catch (err) {
			//throw error in json response with status 500. 
			return apiResponse.ErrorResponse(res, err);
		}
	}
];

/**
 * Category Delete.
 * 
 * @param {string}      id
 * 
 * @returns {Object}
 */
exports.categoryDelete = [
	auth,
	function (req, res) {
		if(!mongoose.Types.ObjectId.isValid(req.params.id)){
			return apiResponse.validationErrorWithData(res, "Invalid Error.", "Invalid ID");
		}
		try {
			console.log('aaaaaa--------------');
			Category.findById(req.params.id, function (err, foundCategory) {
				if(foundCategory === null){
					return apiResponse.notFoundResponse(res,"Category not exists with this id");
				}else{
					
						Category.findByIdAndRemove(req.params.id,function (err) {
							if (err) { 
								return apiResponse.ErrorResponse(res, err); 
							}else{
								return apiResponse.successResponse(res,"Category delete Success.");
							}
						});
					//}
				}
			});
		} catch (err) {
			//throw error in json response with status 500. 
			return apiResponse.ErrorResponse(res, err);
		}
	}
];