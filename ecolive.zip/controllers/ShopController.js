const Shop = require("../models/ShopModel");
const { body,validationResult } = require("express-validator");
const { sanitizeBody } = require("express-validator");
const apiResponse = require("../helpers/apiResponse");
const auth = require("../middlewares/jwt");
var mongoose = require("mongoose");
const { constants } = require("../helpers/constants");

mongoose.set("useFindAndModify", false);

// Shop Schema
function ShopData(data) {
	this.id = data._id;
	this.shopName= data.shopName;
	this.description = data.description;
	this.category = data.category;
	this.address = data.address;
	this.latitude = data.latitude;
	this.longitude = data.longitude;
	this.zipCode = data.zipCode;
	this.image = data.image;
	this.completeStatus = data.completeStatus,
	this.createdAt = data.createdAt;
	
}

/**
 * Shop List.
 * 
 * @returns {Object}
 */
exports.shopList = [
	auth,
	function (req, res) {
		try {
			let user_id = mongoose.Types.ObjectId(req.user._id);

			console.log(req.user._id);
			const shop_qry = [
				// { $match: {user: req.user._id } },
				{
					$lookup:{
					from: 'users', 
					localField:'user', 
					foreignField:'_id',
					as:'users'
				}
			},
			{$unwind: '$users'},
				{
					$project: { 
						shopName:1,
						user:1,
						createdAt: 1,
						updatedAt: 1,
						description :1,
						category: 1,
						address : 1,
						latitude : 1,
						longitude : 1,
						zipCode : 1,
						completeStatus:1,
						image: {
							$concat:
							[
							// {$cond:[{$eq:['$image', null]}, "", constants.urlPath.base] },
							{$cond:[{$eq:[{$ifNull:["$image",constants.urlPath.base]},constants.urlPath.base]},"",constants.urlPath.base]},
							{$ifNull:["$image",""]}
							]
						  },
						userName : "$users.userName",
						//image:{$concat:[constants.urlPath.base]}
					}
				  },
				{ '$sort'     : { 'createdAt' : -1 } },
			{ $facet : {payload : [ { $skip: 0 }, {$limit: 100 } ] } }
			]
			console.log(user_id);
			if (req.user._id) {
				shop_qry.unshift({ $match: {user: user_id } });
			}
			Shop.aggregate(shop_qry).exec((err, result)=>{
				if (err) {
					//console.log("error" ,err)
					return apiResponse.ErrorResponse(res, err);
				}
				if (result) {
					//console.log(result);
					return apiResponse.successResponseWithData(res,"Shop Success.", result[0].payload);

				}
		  	});
			// Shop.find({user: req.user._id},"_id user shopName description category address latitude longitude zipCode image createdAt").then((shops)=>{
			// 	if(shops.length > 0){
			// 		var i = 0;
			// 		shops.forEach(function(shop) {
			// 			if(typeof shop.image === 'undefined')
			// 			{
			// 				shops[i].image = '';
			// 			}
			// 			else
			// 			{
			// 				shops[i].image = constants.urlPath.base+shop.image;
			// 			}
			// 			i++;
			// 			//console.log(shop.image);
			// 		});
			// 		return apiResponse.successResponseWithData(res, "Operation success", shops);
			// 	}else{
			// 		return apiResponse.successResponseWithData(res, "Operation success", []);
			// 	}
			// });
		} catch (err) {
			//throw error in json response with status 500. 
			return apiResponse.ErrorResponse(res, err);
		}
	}
];

/**
 * Shop Detail.
 * 
 * @param {string} id
 * 
 * @returns {Object}
 */
exports.shopDetail = [
	auth,
	function (req, res) {
		if(!mongoose.Types.ObjectId.isValid(req.params.id)){
			return apiResponse.successResponseWithData(res, "Operation success", {});
		}
		try {
			Shop.findOne({_id: req.params.id,user: req.user._id},"_id user shopName description category address latitude longitude zipCode image completeStatus createdAt").then((shop)=>{                
				if(shop !== null){
					let shopData = new ShopData(shop);
					console.log(shop);
					shopData.image = constants.urlPath.base+shopData.image;
					//shopData.completeStatus = shopData.completeStatus;
					return apiResponse.successResponseWithData(res, "Operation success", shopData);
				}else{
					return apiResponse.successResponseWithData(res, "Operation success", {});
				}
			});
		} catch (err) {
			//throw error in json response with status 500. 
			return apiResponse.ErrorResponse(res, err);
		}
	}
];

/**
 * Shop store.
 * 
 * @param {string}  shopName 
 * @param {string}  category
 * @param {string}  address
 * @param {string}  latitude
 * @param {string}  longitude
 * @param {string} 	zipCode
 * @param {string} 	description
 * @returns {Object}
 */
exports.shopStore = [
	auth,
	body("shopName", "shopName must not be empty").isLength({ min: 1 }).trim().custom((value,{req}) => {
		return Shop.findOne({shopName : value,user: req.user._id}).then(shop => {
			if (shop) {
				return Promise.reject("ShopName already exist with this ShopName.");
			}
		});
	}),
	body("category", "category must not be empty.").isLength({ min: 1 }).trim(),
	body("address", "address must not be empty.").isLength({ min: 1 }).trim(),
	body("zipCode", "zipCode must not be empty.").isLength({ min: 1 }).trim(),
	body("latitude", "latitude must not be empty.").isLength({ min: 1 }).trim(),
	body("longitude", "longitude must not be empty.").isLength({ min: 1 }).trim(),
	body("description", "Description must not be empty.").isLength({ min: 1 }).trim(),
	sanitizeBody("*").escape(),
	(req, res) => {
		try {
			console.log('aaaa');
			const errors = validationResult(req);
			
			//var completeStatus = typeof req.body.completeStatus === 'undefined' ? false : req.body.completeStatus;
			var shop = new Shop(
				{ 	
					user: req.user,
					shopName: req.body.shopName,
					category: req.body.category,
					address: req.body.address,
					latitude: req.body.latitude,
					longitude: req.body.longitude,
					zipCode : req.body.zipCode,
					description: req.body.description,
					image: req.file.path,
					
				});

			if (!errors.isEmpty()) {
				return apiResponse.validationErrorWithData(res, "Validation Error.", errors.array());
			}
			else {
				//Save shop.
				
				shop.save(function (err) {
					if (err) { return apiResponse.ErrorResponse(res, err); }
					let shopData = new ShopData(shop);
					console.log(shopData);
					shopData.image = constants.urlPath.base+shopData.image;
					return apiResponse.successResponseWithData(res,"Shop add Success.", shopData);
				});
			}
		} catch (err) {
			//throw error in json response with status 500. 
			return apiResponse.ErrorResponse(res, err);
		}
	}
];

/**
 * Shop update.
 * 
 * @param {string}      shopName
 * @param {string}      category
 * @param {string}      zipCode 
 * @param {string}      description
 * @param {string}      address
 * @param {string}      latitude
 * @param {string}      longitude
 
 * 
 * @returns {Object}
 */
exports.shopUpdate = [
	auth,
	body("shopName", "shopName must not be empty.").isLength({ min: 1 }).trim(),
	body("category", "category must not be empty.").isLength({ min: 1 }).trim(),
	body("address", "address must not be empty.").isLength({ min: 1 }).trim(),
	body("latitude", "latitude must not be empty.").isLength({ min: 1 }).trim(),
	body("longitude", "longitude must not be empty.").isLength({ min: 1 }).trim(),
	body("zipCode", "zipCode must not be empty.").isLength({ min: 1 }).trim(),
	body("description", "Description must not be empty.").isLength({ min: 1 }).trim().custom((value,{req}) => {
		return Shop.findOne({isbn : value,user: req.user._id, _id: { "$ne": req.params.id }}).then(shop => {
			if (shop) {
				return Promise.reject("Shop already exist with this ISBN no.");
			}
		});
	}),
	sanitizeBody("*").escape(),
	(req, res) => {
		try {
			const errors = validationResult(req);
			var shop = new Shop(
				{ 
					user: req.user,
					shopName: req.body.shopName,
					description: req.body.description,
					category: req.body.category,
					address: req.body.address,
					latitude: req.body.latitude,
					longitude: req.body.longitude,
					zipCode: req.body.zipCode,
					image: req.file.path,
					completeStatus : true,
					_id:req.params.id
				});

			if (!errors.isEmpty()) {
				return apiResponse.validationErrorWithData(res, "Validation Error.", errors.array());
			}
			else {
				if(!mongoose.Types.ObjectId.isValid(req.params.id)){
					return apiResponse.validationErrorWithData(res, "Invalid Error.", "Invalid ID");
				}else{
					Shop.findById(req.params.id, function (err, foundShop) {
						if(foundShop === null){
							return apiResponse.notFoundResponse(res,"Shop not exists with this id");
						}else{
							//Check authorized user
							if(foundShop.user.toString() !== req.user._id){
								return apiResponse.unauthorizedResponse(res, "You are not authorized to do this operation.");
							}else{
								//update shop.
								Shop.findByIdAndUpdate(req.params.id, shop, {},function (err) {
									if (err) { 
										return apiResponse.ErrorResponse(res, err); 
									}else{
										let shopData = new ShopData(shop);
										shopData.image = constants.urlPath.base+shopData.image;
										
										return apiResponse.successResponseWithData(res,"Shop update Success.", shopData);
									}
								});
							}
						}
					});
				}
			}
		} catch (err) {
			//throw error in json response with status 500. 
			return apiResponse.ErrorResponse(res, err);
		}
	}
];

/**
 * Shop Delete.
 * 
 * @param {string}      id
 * 
 * @returns {Object}
 */
exports.shopDelete = [
	auth,
	function (req, res) {
		if(!mongoose.Types.ObjectId.isValid(req.params.id)){
			return apiResponse.validationErrorWithData(res, "Invalid Error.", "Invalid ID");
		}
		try {
			Shop.findById(req.params.id, function (err, foundShop) {
				if(foundShop === null){
					return apiResponse.notFoundResponse(res,"Shop not exists with this id");
				}else{
					//Check authorized user
					if(foundShop.user.toString() !== req.user._id){
						return apiResponse.unauthorizedResponse(res, "You are not authorized to do this operation.");
					}else{
						//delete shop.
						Shop.findByIdAndRemove(req.params.id,function (err) {
							if (err) { 
								return apiResponse.ErrorResponse(res, err); 
							}else{
								return apiResponse.successResponse(res,"Shop delete Success.");
							}
						});
					}
				}
			});
		} catch (err) {
			//throw error in json response with status 500. 
			return apiResponse.ErrorResponse(res, err);
		}
	}
];