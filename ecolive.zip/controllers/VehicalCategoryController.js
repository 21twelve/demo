const VehicalCategory = require("../models/VehicalCategoryModel");
const { body,validationResult } = require("express-validator");
const { sanitizeBody } = require("express-validator");
const apiResponse = require("../helpers/apiResponse");
const auth = require("../middlewares/jwt");
var mongoose = require("mongoose");
mongoose.set("useFindAndModify", false);

// Vehical Category Schema
function VehicalCategoryData(data) {
	this.id = data._id;
	this.name= data.name;
	this.description = data.description;
	this.image = data.image;
	this.createdAt = data.createdAt;
	this.updatedAt = data.updatedAt;
}

/**
 * Vehical Category List.
 * 
 * @returns {Object}
 */
exports.vehicalCategoryList = [
//	auth,
	function (req, res) {
		try {
			VehicalCategory.find({},"_id name description image createdAt").then((vehicalCategorys)=>{
				if(vehicalCategorys.length > 0){
					return apiResponse.successResponseWithData(res, "Operation success", vehicalCategorys);
				}else{
					return apiResponse.successResponseWithData(res, "Operation success", []);
				}
			});
		} catch (err) {
			//throw error in json response with status 500. 
			return apiResponse.ErrorResponse(res, err);
		}
	}
];

/**
 * Vehical category store.
 * 
 * @param {string}  name 
 * @param {string} 	description
 * @returns {Object}
 */
exports.vehicalCategoryStore = [
	//auth,
	body("name", "name must not be empty.").isLength({ min: 1 }).trim(),
	body("description", "Description must not be empty.").isLength({ min: 1 }).trim().custom((value,{req}) => {
		return VehicalCategory.findOne({name : value}).then(VehicalCategory => {
			if (VehicalCategory) {
				return Promise.reject("Category already exist with this shop name.");
			}
		});
	}),
	sanitizeBody("*").escape(),
	(req, res) => {
		try {
			const errors = validationResult(req);
			var vehicalCategory = new VehicalCategory(
				{ 	
					name: req.body.name,
					description: req.body.description,
				});
				
			if (!errors.isEmpty()) {
				return apiResponse.validationErrorWithData(res, "Validation Error.", errors.array());
			}
			else {
				//Save shop.
				vehicalCategory.save(function (err) {
					if (err) { return apiResponse.ErrorResponse(res, err); }
					console.log('hhhhhhhhhhh')
					let vehicalCategoryData = new VehicalCategoryData(vehicalCategory);
					return apiResponse.successResponseWithData(res,"Vehical category add Success.", vehicalCategoryData);
				});
			}
		} catch (err) {
			//throw error in json response with status 500. 
			return apiResponse.ErrorResponse(res, err);
		}
	}
];

/**
 * Vehical category update.
 *
 * @param {string}      name
 * @param {string}      description
 * 
 * @returns {Object}
 */
exports.vehicalCategoryUpdate = [
	auth,
	body("name", "name must not be empty.").isLength({ min: 1 }).trim(),
	body("description", "Description must not be empty.").isLength({ min: 1 }).trim().custom((value,{req}) => {
		return VehicalCategory.findOne({name: req.params.name,_id: { "$ne": req.params.id }}).then(vehicalCategory => {
			if (vehicalCategory) {
				console.log('req.params.id',req.params.id)
				return Promise.reject("Vehical Category already exist with this no.");
			}
		});
	}),
	sanitizeBody("*").escape(),
	(req, res) => {
		try {
			const errors = validationResult(req);
			var vehicalCategory = new VehicalCategory(
				{ 
					name: req.body.name,
					description: req.body.description,
					_id:req.params.id
				});

			if (!errors.isEmpty()) {
				return apiResponse.validationErrorWithData(res, "Validation Error.", errors.array());
			}
			else {
				if(!mongoose.Types.ObjectId.isValid(req.params.id)){
					return apiResponse.validationErrorWithData(res, "Invalid Error.", "Invalid ID");
				}else{
					VehicalCategory.findById(req.params.id, function (err, foundVehicalCategory) {
						if(foundVehicalCategory === null){
							return apiResponse.notFoundResponse(res,"Vehical category not exists with this id");
						}else{
							//Check authorized user
							// if(foundShopCategory.user.toString() !== req.user._id){
							// 	return apiResponse.unauthorizedResponse(res, "You are not authorized to do this operation.");
							// }else{
								//update shop.
								VehicalCategory.findByIdAndUpdate(req.params.id, vehicalCategory, {},function (err) {
									if (err) { 
										return apiResponse.ErrorResponse(res, err); 
									}else{
										let vehicalCategoryData = new VehicalCategoryData(vehicalCategory);
										return apiResponse.successResponseWithData(res,"Vehical update Success.", vehicalCategoryData);
									}
								});
							//}
						}
					});
				}
			}
		} catch (err) {
			//throw error in json response with status 500. 
			return apiResponse.ErrorResponse(res, err);
		}
	}
];

/**
 * Shop Category Delete.
 * 
 * @param {string}      id
 * 
 * @returns {Object}
 */
exports.vehicalCategoryDelete = [
	auth,
	function (req, res) {
		if(!mongoose.Types.ObjectId.isValid(req.params.id)){
			return apiResponse.validationErrorWithData(res, "Invalid Error.", "Invalid ID");
		}
		try {
			VehicalCategory.findById(req.params.id, function (err, foundVehicalCategory) {
				if(foundVehicalCategory === null){
					return apiResponse.notFoundResponse(res,"Shop category not exists with this id");
				}else{
					//Check authorized user
					// if(foundShopCategory.user.toString() !== req.user._id){
					// 	return apiResponse.unauthorizedResponse(res, "You are not authorized to do this operation.");
					// }else{
						//delete shop.
						VehicalCategory.findByIdAndRemove(req.params.id,function (err) {
							if (err) { 
								return apiResponse.ErrorResponse(res, err); 
							}else{
								return apiResponse.successResponse(res,"Vehical category delete Success.");
							}
						});
					//}
				}
			});
		} catch (err) {
			//throw error in json response with status 500. 
			return apiResponse.ErrorResponse(res, err);
		}
	}
];