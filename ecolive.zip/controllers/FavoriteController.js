const Favorite = require("../models/FavoriteModel");
const Product = require("../models/ProductModel");
const Cateogry = require("../models/CategoryModel");
const SubCategory = require("../models/SubCategoryModel");
const Shop = require("../models/ShopModel");
const ProductImages = require("../models/ProductImagesModel");
const { body,validationResult } = require("express-validator");
const { sanitizeBody } = require("express-validator");
const apiResponse = require("../helpers/apiResponse");
const auth = require("../middlewares/jwt");
var mongoose = require("mongoose");
const { constants } = require("../helpers/constants");
mongoose.set("useFindAndModify", false);

// Favorite Schema
function FavoriteData(data) {
	this.id = data._id;
	this.productId = data.productId;
	this.userId = data.userId;
	this.createdAt = data.createdAt;
}

/**
 * Favorite List.
 * 
 * @returns {Object}
 */
exports.favoriteList = [
	auth,
	function (req, res) {
		try {
			// Favorite.find({userId: req.user._id},"").then((favorites)=>{
			// 	if(favorites.length > 0){
			// 		console.log(favorites);
			// 	}
			// });
			let user_id = mongoose.Types.ObjectId(req.user._id);
			const pro_qry = [
				{
					$lookup:{
					from: 'products', 
					localField:'productId', 
					foreignField:'_id',
					as:'products'
				}
			},
			{$unwind: '$products'},
			{
				$lookup:{
					from: 'productimages', 
					localField:'products._id', 
					foreignField:'product',
					as:'images'
				}
			},
			{$unwind: '$images'},
				{
					$group: {
					  _id : "$_id",
					  userId : { $first: "$userId" },
					  productId : { $first: "$productId" },
					  product_id : { $first: "$products.name" },
					  name: { $first: "$products.name" },
					  live_price: { $first: "$products.live_price" },
					  online_price: { $first: "$products.online_price" },
					  live_delvery: { $first: "$products.live_delvery" },
					  online_delvery: { $first: "$products.online_delvery" },
					  colors: { $first: "$products.colors" },
					  description: { $first: "$products.description" },
					  category: { $first: "$products.category" },
					  subcategory: { $first: "$products.subcategory" },
					  qty: { $first: "$products.qty" },
					  shop: { $first: "$products.shop" },
					  createdAt: { $first: "$products.createdAt" },
					  updatedAt: { $first: "$products.updatedAt" },
					  images: {
							$push: {
								_id: "$images._id",
								name: "$images.name",
								image: "$images.image",
								product: "$images.product",
								createdAt: "$images.createdAt",
								updatedAt: "$images.updatedAt",
								image:  {$concat:[constants.urlPath.base, "$images.image"]},
								
							}
						}     
					      
					 
					}
				  },
				{
					$project: { 
						productId:1,
						userId:1,
						qty: 1,
						live_price: 1,
						online_price: 1,
						live_delvery: 1,
						online_delvery: 1,
						colors: 1,
						name: 1,
						description: 1,
						category: 1,
						subcategory: 1,
						qty:1,
						shop: 1,
						createdAt: 1,
						updatedAt: 1,
						images: "$images",
					}
				  },
				{ '$sort'     : { 'createdAt' : -1 } },
			{ $facet : { length : [ { $count : "total" }], payload : [ { $skip: 0 }, {$limit: 20 } ] } }
			]
			

			

			if (user_id) {
				console.log('user_iduser_iduser_iduser_id',user_id)
				pro_qry.unshift({ $match: {userId: user_id } });
			}

			  Favorite.aggregate(pro_qry).exec((err, result)=>{
				if (err) {
					//console.log("error" ,err)
					return apiResponse.ErrorResponse(res, err);
				}
				if (result) {
					//console.log(result);
					return apiResponse.successResponseWithData(res,"Product search Success.", result[0]);

				}
		  });
		} catch (err) {
			//throw error in json response with status 500. 
			return apiResponse.ErrorResponse(res, err);
		}
	}
];

/**
 * Favorite store.
 * 
 * @param {string}  productId 
 * @param {string}  userId
 * @returns {Object}
 */
exports.favoriteStore = [
	auth,
	body("productId", "productId must not be empty.").isLength({ min: 1 }).trim().custom((value,{req}) => {
		return Favorite.findOne({productId : value,userId: req.user._id}).then(favorite => {
			if (favorite) {
				return Promise.reject("This product is already exist in your favorite list.");
			}
		});
	}),
	sanitizeBody("*").escape(),
	(req, res) => {
		try {
			const errors = validationResult(req);
			var favorite = new Favorite(
				{ 	
					userId: req.user,
					productId: req.body.productId,
					description: req.body.description,
				});

			if (!errors.isEmpty()) {
				return apiResponse.validationErrorWithData(res, "Validation Error.", errors.array());
			}
			else {
				//Save favorite.
				favorite.save(function (err) {
					if (err) { return apiResponse.ErrorResponse(res, err); }
					let favoriteData = new FavoriteData(favorite);
						if(favoriteData.productId)
						{
						//	console.log('avoriteData.productId',favoriteData.productId);
							let pro_id = mongoose.Types.ObjectId(favoriteData.productId);
							const pro_qry = [
								{ $match: {_id: pro_id } },
								{
									$lookup:{
									from: 'productimages', 
									localField:'_id', 
									foreignField:'product',
									as:'images'
								}
							},
							{$unwind: '$images'},
							{
								$group: {
								_id : "$_id",
								name: { $first: "$name" },
								live_price: { $first: "$live_price" },
								online_price: { $first: "$online_price" },
								live_delvery: { $first: "$live_delvery" },
								online_delvery: { $first: "$online_delvery" },
								colors: { $first: "$colors" },
								description: { $first: "$description" },
								category: { $first: "$category" },
								subcategory: { $first: "$subcategory" },
								shop: { $first: "$shop" },
								qty: { $first: "$qty" },
								createdAt: { $first: "$createdAt" },
								updatedAt: { $first: "$updatedAt" },
								categoryName: { $first: "$updatedAt" },
								subcategoryName: { $first: "$updatedAt" },
								images: {
									$push: {
										_id: "$images._id",
										name: "$images.name",
										image: "$images.image",
										product: "$images.product",
										createdAt: "$images.createdAt",
										updatedAt: "$images.updatedAt",
										image:  {$concat:[constants.urlPath.base, "$images.image"]},
										
									}
								}        
								//images: { $first: "$images" },
								}
							},
							{
								$project: { 
									qty: 1,
									live_price: 1,
									online_price: 1,
									live_delvery: 1,
									online_delvery: 1,
									colors: 1,
									name: 1,
									description: 1,
									category: 1,
									subcategory: 1,
									qty:1,
									shop: 1,
									createdAt: 1,
									updatedAt: 1,
									images: "$images",
									
									
								}
							},
							// { $facet : { length : [ { $count : "total" }], payload : [ { $skip: 0 }, {$limit: 20 } ] } }
							]
							//pro_qry.unshift({ $match: {_id: cat_id } });
							Product.aggregate(pro_qry).exec((err, result)=>{
								if (err) {
									//console.log("error" ,err)
									return apiResponse.ErrorResponse(res, err);
								}
								if (result) {
									
									return apiResponse.successResponseWithData(res,"Favorite details.", result[0]);
				
								}
						});
					}
					else
					{
						return apiResponse.successResponseWithData(res,"Something went wrong.", favoriteData);
					}
					
				});
			}
		} catch (err) {
			//throw error in json response with status 500. 
			return apiResponse.ErrorResponse(res, err);
		}
	}
];


/**
 * Favorite Delete.
 * 
 * @param {string} id
 * 
 * @returns {Object}
 */
exports.favoriteDelete = [
	auth,
	function (req, res) {
		if(!mongoose.Types.ObjectId.isValid(req.params.id)){
			return apiResponse.validationErrorWithData(res, "Invalid Error.", "Invalid ID");
		}
		try {
			Favorite.findById(req.params.id, function (err, foundFavorite) {
				if(foundFavorite === null){
					return apiResponse.notFoundResponse(res,"Vehical not exists with this id");
				}else{
					//Check authorized user
					if(foundFavorite.userId.toString() !== req.user._id){
						return apiResponse.unauthorizedResponse(res, "You are not authorized to do this operation.");
					}else{
						//delete vehical.
						Favorite.findByIdAndRemove(req.params.id,function (err) {
							if (err) { 
								return apiResponse.ErrorResponse(res, err); 
							}else{
								return apiResponse.successResponse(res,"Unfavorite Success.");
							}
						});
					}
				}
			});
		} catch (err) {
			//throw error in json response with status 500. 
			return apiResponse.ErrorResponse(res, err);
		}
	}
];