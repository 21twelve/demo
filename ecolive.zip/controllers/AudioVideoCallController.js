const AudioVideoCall = require("../models/AudioVideoCallModel");
const { body,validationResult } = require("express-validator");
const { sanitizeBody } = require("express-validator");
const apiResponse = require("../helpers/apiResponse");
const auth = require("../middlewares/jwt");
var mongoose = require("mongoose");
mongoose.set("useFindAndModify", false);
const AccessToken = require('twilio').jwt.AccessToken;

const defaultIdentity = 'alice';
const callerNumber = '1234567890';

const accountSid = '';
const authToken =  '';
const apiKey = '';
const apiSecret = '';
const outgoingApplicationSid_var = '';
const ios_push_key = '';
const android_push_key = '';

// Audio Video Call Schema
function VehicalData(data) {
	this.id = data._id;
	this.createdAt = data.createdAt;
}

/**
 * Audio Video Call List.
 * 
 * @returns {Object}
 */
exports.accessToken = [
	auth,
	body("identity", "identity must not be empty.").isLength({ min: 1 }).trim(),
	body("requestigDeviceType", "Requestig Device Type must not be empty.").isLength({ min: 1 }).trim(),
	body("plainToken", "plainToken must not be empty.").isLength({ min: 1 }).trim(),
	function (req, res) {
		try {
			const VoiceGrant = AccessToken.VoiceGrant;
			if (requestigDeviceType == 'i') {
				var PCS = ios_push_key;//'CR215bb1481d18e971a96f8acceebc096b';
			} else {
				var PCS = android_push_key;//'CR6c46e815e3c56ed0d22e8e79db2e7fa7';
			}
			const voiceGrant = new VoiceGrant({
				outgoingApplicationSid: outgoingApplicationSid_var,
				// pushCredentialSid: 'CR6c46e815e3c56ed0d22e8e79db2e7fa7'
				pushCredentialSid: PCS,
				incomingAllow: true,
			  });
			  
			const token = new AccessToken(accountSid, apiKey, apiSecret,{identity: identity});
			token.addGrant(voiceGrant);

			var returnData={
                "access_token":token.toJwt()
            }
			if (plainToken == 1) {
				return apiResponse.successResponseWithData(res, "Accss Token", returnData.access_token);
            } else {
				return apiResponse.successResponseWithData(res, "Accss Token", returnData);
            }
		} catch (err) {
			//throw error in json response with status 500. 
			return apiResponse.ErrorResponse(res, err);
		}
	}
];

/**
 * access Token Video Call Detail.
 */
exports.accessTokenVideoCall = [
	auth,
	body("identity", "identity must not be empty.").isLength({ min: 1 }).trim(),
	body("requestigDeviceType", "Requestig Device Type must not be empty.").isLength({ min: 1 }).trim(),
	body("plainToken", "plainToken must not be empty.").isLength({ min: 1 }).trim(),
	body("twilio_video_room", "twilio video room must not be empty.").isLength({ min: 1 }).trim(),
	function (req, res) {
		try {
			var VideoGrant = AccessToken.VideoGrant;
			const token = new AccessToken(accountSid, apiKey, apiSecret);
			token.identity = identity;
			if (requestigDeviceType == 'i') {
				var PCS = ios_push_key;//'CR215bb1481d18e971a96f8acceebc096b';
			} else {
				var PCS = android_push_key;//'CR6c46e815e3c56ed0d22e8e79db2e7fa7';
			}
			const videoGrant = new VideoGrant({
				room: twilio_video_room,
				outgoingApplicationSid: outgoingApplicationSid_var,
				//outgoingApplicationSid: 'AP764c19059042706fe6e17319d5dccbde',
				// pushCredentialSid: 'CR6c46e815e3c56ed0d22e8e79db2e7fa7'
				pushCredentialSid:PCS
			});
			
			// Add the grant to the token
			token.addGrant(videoGrant);
			var returnData={
				"access_token":token.toJwt()
			}
			if (plainToken == 1) {
				return apiResponse.successResponseWithData(res, "Accss Token", returnData.access_token);
            } else {
				return apiResponse.successResponseWithData(res, "Accss Token", returnData);
            }
		} catch (err) {
			//throw error in json response with status 500. 
			return apiResponse.ErrorResponse(res, err);
		}
	}
];


/**
 * Make Call.
 */
 exports.makeCall = [
	auth,
	function (req, res) {
		try {
			var to = null;
			if (req.method == 'POST') {
			  to = req.body.to;
			} else {
			  to = req.query.to;
			}
			var callerId = req.query.from;
		  
			const voiceResponse = new VoiceResponse();
		  
			if (!to) {
				voiceResponse.say("Congratulations! You have made your first call! Good bye.");
			} else if (genera_function.isNumber(to)) {
				const dial = voiceResponse.dial({callerId : callerNumber});
				dial.number(to);
			} else {
				const dial = voiceResponse.dial({callerId : callerId});
				dial.client(to);
			}
			console.log('Response:' + voiceResponse.toString());
			console.log(' req.body:' +  JSON.stringify(req.body));
		   
			//res.json(voiceResponse.toString());
			return res.send(voiceResponse.toString());
            
		} catch (err) {
			//throw error in json response with status 500. 
			return apiResponse.ErrorResponse(res, err);
		}
	}
];


/**
 * Place Call.
 */
 exports.placeCall = [
	auth,
	async function (req, res) {
		try {
			var to = null;
			if (req.method == 'POST') {
			  to = req.body.to;
			} else {
			  to = req.query.to;
			}
			console.log('Checking TO from placeCall ===> '+req.body);
			// The fully qualified URL that should be consulted by Twilio when the call connects.
			var url = req.protocol + '://' + req.get('host') + '/incoming';
			console.log('url--------'+url);
			const client = require('twilio')(apiKey, apiSecret, { accountSid: accountSid } );

			if (!to) {
				console.log("Calling default client:" + defaultIdentity);
				call = await client.api.calls.create({
				  url: url,
				  to: 'client:' + defaultIdentity,
				  from: 'kelvin111',
				});
			  } else if (genera_function.isNumber(to)) {
				console.log("Calling number:" + to);
				call = await client.api.calls.create({
				  url: url,
				  to: to,
				  from: callerNumber,
				});
			  } else {
				console.log("Calling client:" + to);
				call =  await client.api.calls.create({
				  url: url,
				  to: 'client:' + to,
				  from: callerId,
				});
			  }

			console.log('The recipient '+call.sid)
			//call.then(console.log(call.sid));
			return res.send(call.sid);
            
		} catch (err) {
			//throw error in json response with status 500. 
			return apiResponse.ErrorResponse(res, err);
		}
	}
];


/**
 * Incomming Call.
 */
 exports.incoming = [
	auth,
	function (req, res) {
		try {
			console.log('Response incomming');
			const voiceResponse = new VoiceResponse();
			voiceResponse.say("Congratulations! You have received your first inbound call! Good bye.");
			console.log('Response:' + voiceResponse.toString());
			return res.send(voiceResponse.toString());
            
		} catch (err) {
			//throw error in json response with status 500. 
			return apiResponse.ErrorResponse(res, err);
		}
	}
];


/**
 * Welcome Call.
 */
 exports.welcome = [
	auth,
	function (req, res) {
		try {
			const voiceResponse = new VoiceResponse();
			voiceResponse.say("Welcome to Twilio");
			console.log('Response:' + voiceResponse.toString());
			return res.send(voiceResponse.toString());
		} catch (err) {
			//throw error in json response with status 500. 
			return apiResponse.ErrorResponse(res, err);
		}
	}
];

