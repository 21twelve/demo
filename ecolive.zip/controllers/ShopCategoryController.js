const ShopCategory = require("../models/ShopCategoryModel");
const { body,validationResult } = require("express-validator");
const { sanitizeBody } = require("express-validator");
const apiResponse = require("../helpers/apiResponse");
const auth = require("../middlewares/jwt");
var mongoose = require("mongoose");
mongoose.set("useFindAndModify", false);

// Shop Category Schema
function ShopCategoryData(data) {
	this.id = data._id;
	this.name= data.name;
	this.description = data.description;
	this.image = data.image;
	this.createdAt = data.createdAt;
	this.updatedAt = data.updatedAt;
}

/**
 * Shop Category List.
 * 
 * @returns {Object}
 */
exports.shopCategoryList = [
//	auth,
	function (req, res) {
		try {
			ShopCategory.find({},"_id name description image createdAt").then((shopCategorys)=>{
				if(shopCategorys.length > 0){
					return apiResponse.successResponseWithData(res, "Operation success", shopCategorys);
				}else{
					return apiResponse.successResponseWithData(res, "Operation success", []);
				}
			});
		} catch (err) {
			//throw error in json response with status 500. 
			return apiResponse.ErrorResponse(res, err);
		}
	}
];

/**
 * Shop category store.
 * 
 * @param {string}  name 
 * @param {string} 	description
 * @returns {Object}
 */
exports.shopCategoryStore = [
	auth,
	body("name", "name must not be empty.").isLength({ min: 1 }).trim(),
	body("description", "Description must not be empty.").isLength({ min: 1 }).trim().custom((value,{req}) => {
		return ShopCategory.findOne({name : value}).then(shopCategory => {
			if (shopCategory) {
				return Promise.reject("Category already exist with this shop name.");
			}
		});
	}),
	sanitizeBody("*").escape(),
	(req, res) => {
		try {
			const errors = validationResult(req);
			var shopCategory = new ShopCategory(
				{ 	
					name: req.body.name,
					description: req.body.description,
				});
				
			if (!errors.isEmpty()) {
				return apiResponse.validationErrorWithData(res, "Validation Error.", errors.array());
			}
			else {
				//Save shop.
				shopCategory.save(function (err) {
					if (err) { return apiResponse.ErrorResponse(res, err); }
					console.log('hhhhhhhhhhh')
					let shopCategoryData = new ShopCategoryData(shopCategory);
					return apiResponse.successResponseWithData(res,"Shop category add Success.", shopCategoryData);
				});
			}
		} catch (err) {
			//throw error in json response with status 500. 
			return apiResponse.ErrorResponse(res, err);
		}
	}
];

/**
 * Shop category update.
 *
 * @param {string}      name
 * @param {string}      description
 * 
 * @returns {Object}
 */
exports.shopCategoryUpdate = [
	auth,
	body("name", "name must not be empty.").isLength({ min: 1 }).trim(),
	body("description", "Description must not be empty.").isLength({ min: 1 }).trim().custom((value,{req}) => {
		return ShopCategory.findOne({name: req.params.name,_id: { "$ne": req.params.id }}).then(shopCategory => {
			if (shopCategory) {
				console.log('req.params.id',req.params.id)
				return Promise.reject("Shop Category already exist with this no.");
			}
		});
	}),
	sanitizeBody("*").escape(),
	(req, res) => {
		try {
			const errors = validationResult(req);
			var shopCategory = new ShopCategory(
				{ 
					name: req.body.name,
					description: req.body.description,
					_id:req.params.id
				});

			if (!errors.isEmpty()) {
				return apiResponse.validationErrorWithData(res, "Validation Error.", errors.array());
			}
			else {
				if(!mongoose.Types.ObjectId.isValid(req.params.id)){
					return apiResponse.validationErrorWithData(res, "Invalid Error.", "Invalid ID");
				}else{
					ShopCategory.findById(req.params.id, function (err, foundShopCategory) {
						if(foundShopCategory === null){
							return apiResponse.notFoundResponse(res,"Shop not exists with this id");
						}else{
							//Check authorized user
							// if(foundShopCategory.user.toString() !== req.user._id){
							// 	return apiResponse.unauthorizedResponse(res, "You are not authorized to do this operation.");
							// }else{
								//update shop.
								ShopCategory.findByIdAndUpdate(req.params.id, shopCategory, {},function (err) {
									if (err) { 
										return apiResponse.ErrorResponse(res, err); 
									}else{
										let shopCategoryData = new ShopCategoryData(shopCategory);
										return apiResponse.successResponseWithData(res,"Shop update Success.", shopCategoryData);
									}
								});
							//}
						}
					});
				}
			}
		} catch (err) {
			//throw error in json response with status 500. 
			return apiResponse.ErrorResponse(res, err);
		}
	}
];

/**
 * Shop Category Delete.
 * 
 * @param {string}      id
 * 
 * @returns {Object}
 */
exports.shopCategoryDelete = [
	auth,
	function (req, res) {
		if(!mongoose.Types.ObjectId.isValid(req.params.id)){
			return apiResponse.validationErrorWithData(res, "Invalid Error.", "Invalid ID");
		}
		try {
			ShopCategory.findById(req.params.id, function (err, foundShopCategory) {
				if(foundShopCategory === null){
					return apiResponse.notFoundResponse(res,"Shop category not exists with this id");
				}else{
					//Check authorized user
					// if(foundShopCategory.user.toString() !== req.user._id){
					// 	return apiResponse.unauthorizedResponse(res, "You are not authorized to do this operation.");
					// }else{
						//delete shop.
						ShopCategory.findByIdAndRemove(req.params.id,function (err) {
							if (err) { 
								return apiResponse.ErrorResponse(res, err); 
							}else{
								return apiResponse.successResponse(res,"Shop category delete Success.");
							}
						});
					//}
				}
			});
		} catch (err) {
			//throw error in json response with status 500. 
			return apiResponse.ErrorResponse(res, err);
		}
	}
];