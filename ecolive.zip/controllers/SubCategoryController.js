const SubCategory = require("../models/SubCategoryModel");
const { body,validationResult } = require("express-validator");
const { sanitizeBody } = require("express-validator");
const apiResponse = require("../helpers/apiResponse");
const auth = require("../middlewares/jwt");
var mongoose = require("mongoose");
const { constants } = require("../helpers/constants");
mongoose.set("useFindAndModify", false);

// Category Schema
function SubCategoryData(data) {
	this.id = data._id;
	this.name= data.name;
	this.category =data.category;
	this.description = data.description;
	this.image = data.image;
	this.createdAt = data.createdAt;
}

/**
 * Category List.
 * 
 * @returns {Object}
 */
exports.subCategoryList = [
	auth,
	function (req, res) {
		try {
			
			let category_id = mongoose.Types.ObjectId(req.params.id);
			console.log(category_id);
			const subcat_qry = [
				{ $match: {category: category_id } },
				{
					$lookup:{
					from: 'categories', 
					localField:'category', 
					foreignField:'_id',
					as:'categorys'
				}
			},
			{$unwind: '$categorys'},
				{
					$project: { 
						name:1,
						image:1,
						createdAt: 1,
						updatedAt: 1,
						categorys : "$categorys.name",
						image11: {
							$concat:
							[
							// {$cond:[{$eq:['$image', null]}, "", constants.urlPath.base] },
							{$cond:[{$eq:[{$ifNull:["$image",constants.urlPath.base]},constants.urlPath.base]},"",constants.urlPath.base]},
							{$ifNull:["$image",""]}
							]
						  },
						//image:{$concat:[constants.urlPath.base]}
					}
				  },
				{ '$sort'     : { 'createdAt' : -1 } },
			{ $facet : {payload : [ { $skip: 0 }, {$limit: 100 } ] } }
			]
			
			SubCategory.aggregate(subcat_qry).exec((err, result)=>{
				if (err) {
					//console.log("error" ,err)
					return apiResponse.ErrorResponse(res, err);
				}
				if (result) {
					//console.log(result);
					return apiResponse.successResponseWithData(res,"Subcategory Success.", result[0].payload);

				}
		  	});

			// SubCategory.find({category: req.params.id},"_id user category name description image createdAt").then((subCategory)=>{
			// 	if(subCategory.length > 0){
			// 		var i = 0;
			// 		subCategory.forEach(function(subCategory) {
					
			// 			if(typeof subCategory.image === 'undefined')
			// 			{
			// 				subCategory.image = '';
			// 			}
			// 			else
			// 			{
			// 				subCategory.image =  constants.urlPath.base+subCategory.image;
			// 				//categories[i].image = constants.urlPath.base;
							
			// 			}
			// 			i++;
						
			// 		});
					
			// 		return apiResponse.successResponseWithData(res, "Operation success", subCategory);
			// 	}else{
			// 		return apiResponse.successResponseWithData(res, "Operation success", []);
			// 	}
			// });
		} catch (err) {
			//throw error in json response with status 500. 
			return apiResponse.ErrorResponse(res, err);
		}
	}
];

/**
 * Category Detail.
 * 
 * @param {string} id
 * 
 * @returns {Object}
 */
exports.subCategoryDetail = [
	auth,
	function (req, res) {
		if(!mongoose.Types.ObjectId.isValid(req.params.id)){
			return apiResponse.successResponseWithData(res, "Operation success", {});
		}
		try {
			SubCategory.findOne({_id: req.params.id,user: req.user._id},"_id user name description category image createdAt").then((category)=>{                
				if(category !== null){
					let subCategoryData = new SubCategoryData(category);
					return apiResponse.successResponseWithData(res, "Operation success", subCategoryData);
				}else{
					return apiResponse.successResponseWithData(res, "Operation success", {});
				}
			});
		} catch (err) {
			//throw error in json response with status 500. 
			return apiResponse.ErrorResponse(res, err);
		}
	}
];

/**
 * Shop store.
 * 
 * @param {string}  name 
 * @param {string}  category
 * @param {string} 	description
 * @returns {Object}
 */
exports.subCategoryStore = [
	auth,
	body("catname", "catname must not be empty.").isLength({ min: 1 }).trim(),
	body("category", "categoryame must not be empty.").isLength({ min: 1 }).trim(),
	body("description", "Description must not be empty.").isLength({ min: 1 }).trim().custom((value,{req}) => {
		return SubCategory.findOne({categoryName : value,user: req.user._id}).then(category => {
			if (category) {
				return Promise.reject("Sub Category already exist with this shop name.");
			}
		});
	}),
	sanitizeBody("*").escape(),
	(req, res) => {
		try {
			
			const errors = validationResult(req);
			var subCategory = new SubCategory(
				{ 	
					name: req.body.catname,
					category: req.body.category,
					description: req.body.description,
					 image :req.file.path
				});

			if (!errors.isEmpty()) {
				return apiResponse.validationErrorWithData(res, "Validation Error.", errors.array());
			}
			else {
				//Save shop.
				subCategory.save(function (err) {
					if (err) { return apiResponse.ErrorResponse(res, err); }
					let categoryData = new SubCategoryData(subCategory);
					return apiResponse.successResponseWithData(res,"Category add Success.", categoryData);
				});
			}
		} catch (err) {
			//throw error in json response with status 500. 
			return apiResponse.ErrorResponse(res, err);
		}
	}
];

/**
 * Sub category update.
 * 
 * @param {string}      shopName
 * @param {string}      category
 * @param {string}      zipCode 
 * @param {string}      description
 * @param {string}      address
 * @param {string}      latitude
 * @param {string}      longitude
 
 * 
 * @returns {Object}
 */
exports.subCategoryUpdate = [
	auth,
	body("shopName", "shopName must not be empty.").isLength({ min: 1 }).trim(),
	body("category", "category must not be empty.").isLength({ min: 1 }).trim(),
	body("address", "address must not be empty.").isLength({ min: 1 }).trim(),
	body("latitude", "latitude must not be empty.").isLength({ min: 1 }).trim(),
	body("longitude", "longitude must not be empty.").isLength({ min: 1 }).trim(),
	body("zipCode", "zipCode must not be empty.").isLength({ min: 1 }).trim(),
	body("description", "Description must not be empty.").isLength({ min: 1 }).trim().custom((value,{req}) => {
		return SubCategory.findOne({_id : value,user: req.user._id, _id: { "$ne": req.params.id }}).then(subcateogry => {
			if (subcateogry) {
				return Promise.reject("Subcateogry already exist.");
			}
		});
	}),
	sanitizeBody("*").escape(),
	(req, res) => {
		try {
			const errors = validationResult(req);
			var shop = new Shop(
				{ 
					user: req.user,
					shopName: req.body.shopName,
					description: req.body.description,
					category: req.body.category,
					address: req.body.address,
					latitude: req.body.latitude,
					longitude: req.body.longitude,
					zipCode: req.body.zipCode,
					_id:req.params.id
				});

			if (!errors.isEmpty()) {
				return apiResponse.validationErrorWithData(res, "Validation Error.", errors.array());
			}
			else {
				if(!mongoose.Types.ObjectId.isValid(req.params.id)){
					return apiResponse.validationErrorWithData(res, "Invalid Error.", "Invalid ID");
				}else{
					Shop.findById(req.params.id, function (err, foundShop) {
						if(foundShop === null){
							return apiResponse.notFoundResponse(res,"Shop not exists with this id");
						}else{
							//Check authorized user
							if(foundShop.user.toString() !== req.user._id){
								return apiResponse.unauthorizedResponse(res, "You are not authorized to do this operation.");
							}else{
								//update shop.
								Shop.findByIdAndUpdate(req.params.id, shop, {},function (err) {
									if (err) { 
										return apiResponse.ErrorResponse(res, err); 
									}else{
										let shopData = new ShopData(shop);
										return apiResponse.successResponseWithData(res,"Shop update Success.", shopData);
									}
								});
							}
						}
					});
				}
			}
		} catch (err) {
			//throw error in json response with status 500. 
			return apiResponse.ErrorResponse(res, err);
		}
	}
];

/**
 * Category Delete.
 * 
 * @param {string}      id
 * 
 * @returns {Object}
 */
exports.subCategoryDelete = [
	auth,
	function (req, res) {
		if(!mongoose.Types.ObjectId.isValid(req.params.id)){
			return apiResponse.validationErrorWithData(res, "Invalid Error.", "Invalid ID");
		}
		try {
			SubCategory.findById(req.params.id, function (err, foundSubCategory) {
				if(foundSubCategory === null){
					return apiResponse.notFoundResponse(res,"Shop not exists with this id");
				}else{
					//Check authorized user
				
						//delete shop.
						SubCategory.findByIdAndRemove(req.params.id,function (err) {
							if (err) { 
								return apiResponse.ErrorResponse(res, err); 
							}else{
								return apiResponse.successResponse(res,"Subcategory delete Success.");
							}
						});
					
				}
			});
		} catch (err) {
			//throw error in json response with status 500. 
			return apiResponse.ErrorResponse(res, err);
		}
	}
];