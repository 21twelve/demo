const Product = require("../models/ProductModel");
const Favorite = require("../models/FavoriteModel");
const Cateogry = require("../models/CategoryModel");
const SubCategory = require("../models/SubCategoryModel");
const Shop = require("../models/ShopModel");
const Color = require("../models/ColorModel");
const ProductImages = require("../models/ProductImagesModel");
const { body,validationResult } = require("express-validator");
const { sanitizeBody } = require("express-validator");
const apiResponse = require("../helpers/apiResponse");
const auth = require("../middlewares/jwt");
const multer = require("multer");
const { constants } = require("../helpers/constants");
var mongoose = require("mongoose");

mongoose.set("useFindAndModify", false);

const storage = multer.diskStorage({
    destination: (req, file, cb) => {
      cb(null, "./uploads");
    },
    filename: (req, file, cb) => {
      //cb(null, new Date().toISOString() + file.originalname);
	  cb(null, Date.now()+'-'+file.originalname);
    },
  });
  
  const fileFilter = (req, file, cb) => {
    
    if (file.mimetype === "image/jpeg" || file.mimetype === "image/png") {
      cb(null, true);
    } else {
      cb(null, false);
    }
  };
  
  const upload = multer({
    storage: storage,
    limit: {
      fileSize: 1024 * 1024 * 5,
    },
    fileFilter: fileFilter,
  });



// Category Schema
function ProductData(data) {
	this._id = data._id;
	this.name= data.name;
	this.shop = data.shop
	this.description = data.description;
	this.productImage = data.productImage;
    this.category = data.category
	this.subcategory = data.subcategory;
	this.qty = data.qty;
	this.live_price = data.live_price;
    this.online_price = data.online_price;
    this.live_delvery = data.live_delvery;
    this.online_delvery = data.online_delvery;
	this.online_delvery = data.online_delvery;
	this.colors = data.colors;
	this.createdAt = data.createdAt;
}


/**
 * Product Search.
 * 
 * @returns {Object}
 */
 exports.productSearch = [
	function (req, res) {
		try {	
			//console.log(req.body.subcategory);
			let cat_id = mongoose.Types.ObjectId(req.body.category);
			let subcat_id = mongoose.Types.ObjectId(req.body.subcategory);
			const pro_qry = [
				{
					$lookup:{
					from: 'productimages', 
					localField:'_id', 
					foreignField:'product',
					as:'images'
				}
			},
			{$unwind: '$images'},
			{
				$lookup:{
				from: 'favorites', 
				localField:'_id', 
				foreignField:'_id',
				as:'favorites'
			}
		},
		{ "$match": { "favorites.0": { "$exists": true } } },
		//{$unwind: '$favorites'},
			// {
			// 	$geoNear: {
			// 	  near: { type: 'Point', coordinates: [-73.99279, 40.719296] },
			// 	  distanceField: 'dist.calculated',
			// 	  maxDistance: 2,
			// 	  includeLocs: 'dist.location',
			// 	  spherical: true,
			// 	},
			//   },
				{
					$group: {
					  _id : "$_id",
					  name: { $first: "$name" },
					  live_price: { $first: "$live_price" },
					  online_price: { $first: "$online_price" },
					  live_delvery: { $first: "$live_delvery" },
					  online_delvery: { $first: "$online_delvery" },
					  colors: { $first: "$colors" },
					  description: { $first: "$description" },
					  category: { $first: "$category" },
					  subcategory: { $first: "$subcategory" },
					  qty: { $first: "$qty" },
					  shop: { $first: "$shop" },
					  createdAt: { $first: "$createdAt" },
					  updatedAt: { $first: "$updatedAt" },
					  favorites: { "$first": "$favorites" },
					  images: {
						$push: {
							_id: "$images._id",
							name: "$images.name",
							image: "$images.image",
							product: "$images.product",
							createdAt: "$images.createdAt",
							updatedAt: "$images.updatedAt",
							image:  {$concat:[constants.urlPath.base, "$images.image"]},
							
						}
					}        
					  //images: { $first: "$images" },
					}
				  },
				{
					$project: { 
						qty: 1,
						live_price: 1,
						online_price: 1,
						live_delvery: 1,
						online_delvery: 1,
						colors: 1,
						name: 1,
						description: 1,
						category: 1,
						subcategory: 1,
						qty:1,
						shop: 1,
						createdAt: 1,
						updatedAt: 1,
						images: "$images",
						isFavorite: "$favorites",
						
					}
				  },
				{ '$sort'     : { 'createdAt' : -1 } },
			{ $facet : { length : [ { $count : "total" }], payload : [ { $skip: 0 }, {$limit: 20 } ] } }
			]
			

			if (req.body.subcategory) {
				pro_qry.unshift({ $match: {subcategory: subcat_id } });
			}

			if (req.body.category) {
				pro_qry.unshift({ $match: {_id: cat_id } });
			}

			  Product.aggregate(pro_qry).exec((err, result)=>{
				if (err) {
					//console.log("error" ,err)
					return apiResponse.ErrorResponse(res, err);
				}
				if (result) {
					//console.log(result);
					return apiResponse.successResponseWithData(res,"Product search Success.", result[0]);

				}
		  });
	
		} catch (err) {
			//throw error in json response with status 500. 
			return apiResponse.ErrorResponse(res, err);
		}
		// 	Product.aggregate([
		// 		{
		// 			$lookup:{
		// 			from: 'productimages', 
		// 			localField:'_id', 
		// 			foreignField:'product',
		// 			as:'Product_images'
		// 		}
		// 	},	 
		//   ])
		//   //.sort({ createdAt : 1})
		//   .exec((err, result)=>{
		// 		if (err) {
		// 			//console.log("error" ,err)
		// 			return apiResponse.ErrorResponse(res, err);
		// 		}
		// 		if (result) {
		// 			//console.log(result);
		// 			return apiResponse.successResponseWithData(res,"Product search Success.", result);

		// 		}
		//   });
	
		// } catch (err) {
		// 	//throw error in json response with status 500. 
		// 	return apiResponse.ErrorResponse(res, err);
		// }
	}
];

/**
 * Product productSearch_demo.
 * 
 * @returns {Object}
 */
 exports.productSearch_demo = [
	function (req, res) {
		try {	
			//console.log(req.body.subcategory);
			let cat_id = mongoose.Types.ObjectId(req.body.category);
			let subcat_id = mongoose.Types.ObjectId(req.body.subcategory);
			const pro_qry = [
				{
					$lookup:{
					from: 'productimages', 
					localField:'_id', 
					foreignField:'product',
					as:'images'
				}
			},
			{$unwind: '$images'},
				{
					$group: {
					  _id : "$_id",
					  name: { $first: "$name" },
					  live_price: { $first: "$live_price" },
					  online_price: { $first: "$online_price" },
					  live_delvery: { $first: "$live_delvery" },
					  online_delvery: { $first: "$online_delvery" },
					  colors: { $first: "$colors" },
					  description: { $first: "$description" },
					  category: { $first: "$category" },
					  subcategory: { $first: "$subcategory" },
					  qty: { $first: "$qty" },
					  shop: { $first: "$shop" },
					  createdAt: { $first: "$createdAt" },
					  updatedAt: { $first: "$updatedAt" },
					  
					  images: {
						$push: {
							_id: "$images._id",
							name: "$images.name",
							image: "$images.image",
							product: "$images.product",
							createdAt: "$images.createdAt",
							updatedAt: "$images.updatedAt",
							image:  {$concat:[constants.urlPath.base, "$images.image"]},
							
						}
					}        
					  //images: { $first: "$images" },
					}
				  },
				{
					$project: { 
						qty: 1,
						live_price: 1,
						online_price: 1,
						live_delvery: 1,
						online_delvery: 1,
						colors: 1,
						name: 1,
						description: 1,
						category: 1,
						subcategory: 1,
						qty:1,
						shop: 1,
						createdAt: 1,
						updatedAt: 1,
						images: "$images",
						
						
					}
				  },
				{ '$sort'     : { 'createdAt' : -1 } },
			{ $facet : { length : [ { $count : "total" }], payload : [ { $skip: 0 }, {$limit: 20 } ] } }
			]
			

			if (req.body.subcategory) {
				pro_qry.unshift({ $match: {subcategory: subcat_id } });
			}

			if (req.body.category) {
				pro_qry.unshift({ $match: {_id: cat_id } });
			}

			  Product.aggregate(pro_qry).exec((err, result)=>{
				if (err) {
					//console.log("error" ,err)
					return apiResponse.ErrorResponse(res, err);
				}
				if (result) {
					//console.log(result);
					return apiResponse.successResponseWithData(res,"Product search Success.", result[0]);

				}
		  });
	
		} catch (err) {
			//throw error in json response with status 500. 
			return apiResponse.ErrorResponse(res, err);
		}
		// 	Product.aggregate([
		// 		{
		// 			$lookup:{
		// 			from: 'productimages', 
		// 			localField:'_id', 
		// 			foreignField:'product',
		// 			as:'Product_images'
		// 		}
		// 	},	 
		//   ])
		//   //.sort({ createdAt : 1})
		//   .exec((err, result)=>{
		// 		if (err) {
		// 			//console.log("error" ,err)
		// 			return apiResponse.ErrorResponse(res, err);
		// 		}
		// 		if (result) {
		// 			//console.log(result);
		// 			return apiResponse.successResponseWithData(res,"Product search Success.", result);

		// 		}
		//   });
	
		// } catch (err) {
		// 	//throw error in json response with status 500. 
		// 	return apiResponse.ErrorResponse(res, err);
		// }
	}
];
/**
 * Product List.
 * 
 * @returns {Object}
 */
 exports.productList = [
	auth,
	function (req, res) {
		try {	
				
				let ax = '123';
				
				let shop_id = mongoose.Types.ObjectId(req.params.id);
				let cat_id = mongoose.Types.ObjectId(req.body.category);
				let subcat_id = mongoose.Types.ObjectId(req.body.subcategory);
				console.log(shop_id);
				const pro_qry = [
					{ $match: {shop: shop_id } },
					{
						$lookup:{
						from: 'productimages', 
						localField:'_id', 
						foreignField:'product',
						as:'images'
					}
				},
				{$unwind: '$images'},
				{
					$group: {
					  _id : "$_id",
					  name: { $first: "$name" },
					  live_price: { $first: "$live_price" },
					  online_price: { $first: "$online_price" },
					  live_delvery: { $first: "$live_delvery" },
					  online_delvery: { $first: "$online_delvery" },
					  colors: { $first: "$colors" },
					  description: { $first: "$description" },
					  category: { $first: "$category" },
					  subcategory: { $first: "$subcategory" },
					  shop: { $first: "$shop" },
					  qty: { $first: "$qty" },
					  createdAt: { $first: "$createdAt" },
					  updatedAt: { $first: "$updatedAt" },
					  
					  images: {
						$push: {
							_id: "$images._id",
							name: "$images.name",
							image: "$images.image",
							product: "$images.product",
							createdAt: "$images.createdAt",
							updatedAt: "$images.updatedAt",
							image:  {$concat:[constants.urlPath.base, "$images.image"]},
							
						}
					}        
					  //images: { $first: "$images" },
					}
				  },
				{
					$project: { 
						qty: 1,
						live_price: 1,
						online_price: 1,
						live_delvery: 1,
						online_delvery: 1,
						colors: 1,
						name: 1,
						description: 1,
						category: 1,
						subcategory: 1,
						qty:1,
						shop: 1,
						createdAt: 1,
						updatedAt: 1,
						images: "$images",
						
						
					}
				  },
				  { '$sort'     : { 'createdAt' : -1 } },
				{ $facet : { length : [ { $count : "total" }], payload : [ { $skip: 0 }, {$limit: 20 } ] } }
				]
				
	
				// if (req.body.subcategory) {
				// 	pro_qry.unshift({ $match: {subcategory: subcat_id } });
				// }
	
				
				//pro_qry.unshift({ $match: {shop: req.params.id } });
				
	
				  Product.aggregate(pro_qry).exec((err, result)=>{
					if (err) {
						//console.log("error" ,err)
						return apiResponse.ErrorResponse(res, err);
					}
					if (result) {
						//console.log(result);
						var msg = result[0].length > 0 ? "Product list Success" : "No product found!";
						return apiResponse.successResponseWithData(res,msg, result[0]);
	
					}
			  });
		
			

	// Product.find({_user: req.params.id},"_id name description shop category subcategory qty live_price online_price live_delvery online_delvery colors createdAt")
	// 			.populate({path: 'Shop'})
	// 			.sort({ createdAt : -1})
	// 			.exec((err,results) => {
	// 				if(err) return handleErr(err);
					
	// 				 var i = 0;
					
	// 				var responseArr = [];
	// 				Promise.all(
	// 					results.map(async (resultsPro) => {
						  
	// 					  await ProductImages.find({product:resultsPro._id}).then((productImage)=>{
	// 						// console.log(productImage);
	// 						if(productImage.length > 0){
	// 							//resultsPro.push({img : productImage})
	// 							//console.log(results[i]);
	// 							allImages = productImage.map(function(pImg) {
	// 								pImg.image = constants.urlPath.base+pImg.image;
	// 								return pImg;
	// 							});
	// 							responseArr.push({product:results[i],images:allImages})
	// 							//Object.assign(obj1, obj2);
	// 							console.log(results.images);
	// 							//return apiResponse.successResponseWithData(res,"Product update Success.", results);
	// 						}else{
	// 							responseArr.push({products:results[i],images:[]})
	// 						}
	// 						i++;
	// 					});
						
	// 					  //return await newUpload.save();
	// 					})
	// 				  )
	// 				.then(function(proImage) {
	// 					return apiResponse.successResponseWithData(res,"Product update Success.", responseArr);
	// 					//return apiResponse.successResponseWithData(res,"Product added successfully.",productData);
	// 				})
	// 				.catch((e) => {
	// 						//console.log(newUpload)
	// 						return apiResponse.successResponseWithData(res,"Error in product add.");
	// 					});
					
	// 				//return apiResponse.successResponseWithData(res, "Operation success", results);
	// 			});
	
		} catch (err) {
			//throw error in json response with status 500. 
			return apiResponse.ErrorResponse(res, err);
		}
	}
];
// exports.productList = [
// 	auth,
// 	function (req, res) {
// 		try {	
				
// 				let shop_id = mongoose.Types.ObjectId(req.params.id);
// 				let cat_id = mongoose.Types.ObjectId(req.body.category);
// 				let subcat_id = mongoose.Types.ObjectId(req.body.subcategory);
// 				console.log(shop_id);
// 				const pro_qry = [
// 					{ $match: {shop: shop_id } },
// 					{
// 						$lookup:{
// 						from: 'productimages', 
// 						localField:'_id', 
// 						foreignField:'product',
// 						as:'images'
// 					}
// 				},
// 				{$unwind: '$images'},
// 				{
// 					$group: {
// 					  _id : "$_id",
// 					  name: { $first: "$name" },
// 					  live_price: { $first: "$live_price" },
// 					  online_price: { $first: "$online_price" },
// 					  live_delvery: { $first: "$live_delvery" },
// 					  online_delvery: { $first: "$online_delvery" },
// 					  colors: { $first: "$colors" },
// 					  description: { $first: "$description" },
// 					  category: { $first: "$category" },
// 					  subcategory: { $first: "$subcategory" },
// 					  shop: { $first: "$shop" },
// 					  qty: { $first: "$qty" },
// 					  createdAt: { $first: "$createdAt" },
// 					  updatedAt: { $first: "$updatedAt" },
					  
// 					  images: {
// 						$push: {
// 							_id: "$images._id",
// 							name: "$images.name",
// 							image: "$images.image",
// 							product: "$images.product",
// 							createdAt: "$images.createdAt",
// 							updatedAt: "$images.updatedAt",
// 							image:  {$concat:[constants.urlPath.base, "$images.image"]},
							
// 						}
// 					}        
// 					  //images: { $first: "$images" },
// 					}
// 				  },
// 				{
// 					$project: { 
// 						qty: 1,
// 						live_price: 1,
// 						online_price: 1,
// 						live_delvery: 1,
// 						online_delvery: 1,
// 						colors: 1,
// 						name: 1,
// 						description: 1,
// 						category: 1,
// 						subcategory: 1,
// 						qty:1,
// 						shop: 1,
// 						createdAt: 1,
// 						updatedAt: 1,
// 						images: "$images",
						
						
// 					}
// 				  },
// 				  { '$sort'     : { 'createdAt' : -1 } },
// 				{ $facet : { length : [ { $count : "total" }], payload : [ { $skip: 0 }, {$limit: 20 } ] } }
// 				]
				
	
// 				// if (req.body.subcategory) {
// 				// 	pro_qry.unshift({ $match: {subcategory: subcat_id } });
// 				// }
	
				
// 				//pro_qry.unshift({ $match: {shop: req.params.id } });
				
	
// 				  Product.aggregate(pro_qry).populate('category').exec((err, result)=>{
// 					if (err) {
// 						//console.log("error" ,err)
// 						return apiResponse.ErrorResponse(res, err);
// 					}
// 					if (result) {
// 						//console.log(result);
// 						var msg = result[0].length > 0 ? "Product list Success" : "No product found!";
// 						return apiResponse.successResponseWithData(res,msg, result[0]);
	
// 					}
// 			  });
		
			

// 	// Product.find({_user: req.params.id},"_id name description shop category subcategory qty live_price online_price live_delvery online_delvery colors createdAt")
// 	// 			.populate({path: 'Shop'})
// 	// 			.sort({ createdAt : -1})
// 	// 			.exec((err,results) => {
// 	// 				if(err) return handleErr(err);
					
// 	// 				 var i = 0;
					
// 	// 				var responseArr = [];
// 	// 				Promise.all(
// 	// 					results.map(async (resultsPro) => {
						  
// 	// 					  await ProductImages.find({product:resultsPro._id}).then((productImage)=>{
// 	// 						// console.log(productImage);
// 	// 						if(productImage.length > 0){
// 	// 							//resultsPro.push({img : productImage})
// 	// 							//console.log(results[i]);
// 	// 							allImages = productImage.map(function(pImg) {
// 	// 								pImg.image = constants.urlPath.base+pImg.image;
// 	// 								return pImg;
// 	// 							});
// 	// 							responseArr.push({product:results[i],images:allImages})
// 	// 							//Object.assign(obj1, obj2);
// 	// 							console.log(results.images);
// 	// 							//return apiResponse.successResponseWithData(res,"Product update Success.", results);
// 	// 						}else{
// 	// 							responseArr.push({products:results[i],images:[]})
// 	// 						}
// 	// 						i++;
// 	// 					});
						
// 	// 					  //return await newUpload.save();
// 	// 					})
// 	// 				  )
// 	// 				.then(function(proImage) {
// 	// 					return apiResponse.successResponseWithData(res,"Product update Success.", responseArr);
// 	// 					//return apiResponse.successResponseWithData(res,"Product added successfully.",productData);
// 	// 				})
// 	// 				.catch((e) => {
// 	// 						//console.log(newUpload)
// 	// 						return apiResponse.successResponseWithData(res,"Error in product add.");
// 	// 					});
					
// 	// 				//return apiResponse.successResponseWithData(res, "Operation success", results);
// 	// 			});
	
// 		} catch (err) {
// 			//throw error in json response with status 500. 
// 			return apiResponse.ErrorResponse(res, err);
// 		}
// 	}
// ];

/**
 * Product Detail.
 * 
 * @param {string} id
 * 
 * @returns {Object}
 */
exports.productDetail = [
	//auth,
	function (req, res) {
		if(!mongoose.Types.ObjectId.isValid(req.params.id)){
			return apiResponse.successResponseWithData(res, "Operation success", {});
		}
		try {
			let pro_id = mongoose.Types.ObjectId(req.params.id);
			const pro_qry = [
				{ $match: {_id: pro_id } },
				{
					$lookup:{
					from: 'productimages', 
					localField:'_id', 
					foreignField:'product',
					as:'images'
				}
			},
			{$unwind: '$images'},
			{
				$group: {
				  _id : "$_id",
				  name: { $first: "$name" },
				  live_price: { $first: "$live_price" },
				  online_price: { $first: "$online_price" },
				  live_delvery: { $first: "$live_delvery" },
				  online_delvery: { $first: "$online_delvery" },
				  colors: { $first: "$colors" },
				  description: { $first: "$description" },
				  category: { $first: "$category" },
				  subcategory: { $first: "$subcategory" },
				  shop: { $first: "$shop" },
				  qty: { $first: "$qty" },
				  createdAt: { $first: "$createdAt" },
				  updatedAt: { $first: "$updatedAt" },
				  categoryName: { $first: "$updatedAt" },
				  subcategoryName: { $first: "$updatedAt" },
				  images: {
					$push: {
						_id: "$images._id",
						name: "$images.name",
						image: "$images.image",
						product: "$images.product",
						createdAt: "$images.createdAt",
						updatedAt: "$images.updatedAt",
						image:  {$concat:[constants.urlPath.base, "$images.image"]},
						
					}
				}        
				  //images: { $first: "$images" },
				}
			  },
			{
				$project: { 
					qty: 1,
					live_price: 1,
					online_price: 1,
					live_delvery: 1,
					online_delvery: 1,
					colors: 1,
					name: 1,
					description: 1,
					category: 1,
					subcategory: 1,
					qty:1,
					shop: 1,
					createdAt: 1,
					updatedAt: 1,
					images: "$images",
					
					
				}
			  },
			// { $facet : { length : [ { $count : "total" }], payload : [ { $skip: 0 }, {$limit: 20 } ] } }
			]
			//pro_qry.unshift({ $match: {_id: cat_id } });
			  Product.aggregate(pro_qry).exec((err, result)=>{
				if (err) {
					//console.log("error" ,err)
					return apiResponse.ErrorResponse(res, err);
				}
				if (result) {
					console.log(req.params.id);
					return apiResponse.successResponseWithData(res,"Product details.", result[0]);

				}
		  });
		} catch (err) {
			//throw error in json response with status 500. 
			return apiResponse.ErrorResponse(res, err);
		}
	}
];

/**
 * Product store.
 * 
 * @param {string}  name 
 * @param {string} 	description
 * @param {string} 	category
 * @param {string}  shop
 * @returns {Object} subcategory
 */
exports.productStore = [
	auth,
	body("name", "name must not be empty.").isLength({ min: 1 }).trim(),
    body("description", "description must not be empty.").isLength({ min: 1 }).trim(),
    body("shop", "shop must not be empty.").isLength({ min: 1 }).trim(),
    body("category", "category must not be empty.").isLength({ min: 1 }).trim(),
	body("subcategory", "subcategory must not be empty.").isLength({ min: 1 }).trim(),
	body("qty", "quantity must not be empty.").isLength({ min: 1 }).trim(),
	body("live_price", "live price must not be empty.").isLength({ min: 1 }).trim(),
	body("online_price", "online price must not be empty.").isLength({ min: 1 }).trim(),
	sanitizeBody("*").escape(),
	(req, res) => {
       //console.log('11111111',req.files)

	    var colorObj = req.body.colors;
	    let colorObjVal = colorObj.replace(/&quot;/g,'"');

		try {
			
			const errors = validationResult(req);
			var product = new Product(
				{ 	
					name: req.body.name,
					description: req.body.description,
                    category: req.body.category,
					subcategory: req.body.subcategory,
                    shop: req.body.shop,
					qty: req.body.qty,
					live_price: req.body.live_price,
					online_price: req.body.online_price,
					live_delvery: req.body.live_delvery,
					online_delvery: req.body.online_delvery,
					colors: colorObjVal,
                    //productImage: req.file.path
				});
			console.log('Heeeeeeee');
			if (!errors.isEmpty()) {
				return apiResponse.validationErrorWithData(res, "Validation Error.", errors.array());
			}
			else {
				//Save product image.
				product.save(function (err) {
					if (err) { return apiResponse.ErrorResponse(res, err); }
					let productData = new ProductData(product);
					
					// ProductImages.find().then((productImage)=>{
					// 	if(productImage.length > 0){
							//console.log(productData);
					// 	}else{
					// 		console.log('aaaaaaaaaaa');
					// 		//return apiResponse.successResponseWithData(res, "Operation success", []);
					// 	}
					// });
					var responseArr = [];
					////////////////////////////////// image upload Start ///////////////////////
					if(typeof req.files !== 'undefined' && req.files.length  > 0)
					{
						Promise.all(
							req.files.map(async (file) => {
							  const newUpload = new ProductImages({
								name: file.filename,
								image: file.path,
								product: product._id,
							  });
						
							  return await newUpload.save();
							})
						  )
						.then(function(proImage) {
							//console.log(proImage)
							console.log('aaaaaaaaaaa');
							allImages = proImage.map(function(pImg) {
								//console.log(pImg.image)
								pImg.image = constants.urlPath.base+pImg.image;
								return pImg;
							});
							
							//var responseArr1 = {product:productData,images:allImages};
							//productData.pro = allImages; 
							productData.images = allImages; 
							//console.log(allImages);
							let color = productData.colors;
							//productData.colors = JSON.parse(color.replace(/&quot;/g,'"'));
							///console.log(productData.colors);
							return apiResponse.successResponseWithData(res,"Product added successfully.",productData);
						})
						.catch((e) => {
								//console.log(newUpload)
								return apiResponse.successResponseWithData(res,"Error in product add.");
							});
						// var productImages = new ProductImagesModel(
						// 	{
						// 		product:product._id,
						// 	}
						// );
						// productImages.save(function (err) {
						// 	if (err) { return apiResponse.ErrorResponse(res, err); }
						// 	userData.shopId = shop._id;
						// 	userData.shopName = shop.shopName;
						// 	userData.shopCategory = shop.category;
							//return apiResponse.successResponseWithData(res,"Registration Success.");
						// });

					}
					////////////////// End image upload /////////////////

					
				});
			}
		} catch (err) {
			//throw error in json response with status 500. 
			return apiResponse.ErrorResponse(res, err);
		}
	}
];

/**
 * Shop update.
 * 
 * @param {string}      shopName
 * @param {string}      category
 * @param {string}      zipCode 
 * @param {string}      description
 * @param {string}      address
 * @param {string}      latitude
 * @param {string}      longitude
 
 * 
 * @returns {Object}
 */

exports.productUpdate = [
	auth,
	body("name", "name must not be empty.").isLength({ min: 1 }).trim(),
    body("description", "description must not be empty.").isLength({ min: 1 }).trim(),
    body("shop", "shop must not be empty.").isLength({ min: 1 }).trim(),
    body("category", "category must not be empty.").isLength({ min: 1 }).trim(),
	body("subcategory", "subcategory must not be empty.").isLength({ min: 1 }).trim(),
	body("qty", "quantity must not be empty.").isLength({ min: 1 }).trim(),
	body("live_price", "live price must not be empty.").isLength({ min: 1 }).trim(),
	body("online_price", "online price must not be empty.").isLength({ min: 1 }).trim(),
	sanitizeBody("*").escape(),
	(req, res) => {
		try {
			//var postData = JSON.parse(req.body.colors);
			var colorObj = req.body.colors;
			//let strVals = clr.match(/(?<=":")([^:]+?)(?="(?=,|}|]))/g) //[ '“Fuel” Natural Fish Food - "Fuel" Natural Fish Food','0.00','Aqua Design Innovations' ]
			let strVals = colorObj.replace(/&quot;/g,'"');

			//console.log(strVals);
			const errors = validationResult(req);
			
			var product = new Product(
				{ 
					name: req.body.name,
					description: req.body.description,
                    category: req.body.category,
					subcategory: req.body.subcategory,
					shipping_adr_id:req.body.shipping_adr_id,
                    shop: req.body.shop,
					qty: req.body.qty,
					live_price: req.body.live_price,
					online_price: req.body.online_price,
					live_delvery: req.body.live_delvery,
					online_delvery: req.body.online_delvery,
					colors: strVals,
					_id:req.params.id
				});

			if (!errors.isEmpty()) {
				return apiResponse.validationErrorWithData(res, "Validation Error.", errors.array());
			}
			else {
				if(!mongoose.Types.ObjectId.isValid(req.params.id)){
					return apiResponse.validationErrorWithData(res, "Invalid Error.", "Invalid ID");
				}else{
					
					Product.findById(req.params.id, function (err, foundProduct) {
						if(foundProduct === null){
							return apiResponse.notFoundResponse(res,"Product not exists with this id");
						}else{
							var responseArr = [];


								Product.findByIdAndUpdate(req.params.id, product, {runValidators: false, useFindAndModify: false, new: false },function (err) {
									if (err) { 
                                        console.log(err)
										return apiResponse.ErrorResponse(res, err); 
									}else{
									//	console.log('aaaaaaaaaaaaaaaaa');
										let productData = new ProductData(product);
										//let color = productData.colors;
										//productData.colors = JSON.parse(color.replace(/&quot;/g,'"'));
										console.log(productData.colors);
										//////////// image delete start ///////////
										const promiseA = new Promise(function(resolve, reject) {
											ProductImages.find({product:req.params.id}).then((productImage)=>{
												if(productImage.length > 0){
													
													ProductImages.deleteMany({ product: req.params.id},function (err) {
														if (err) { 
															resolve(true);
															//return apiResponse.ErrorResponse(res, err); 
														}else{
															resolve(true);
															//return apiResponse.successResponse(res,"Product delete Success.");
														}
													});
													
												}else{
													resolve(true);
												}
											});
										});

										promiseA.then(value => {
										////////////////////////////////// image upload Start ///////////////////////
												if(typeof req.files !== 'undefined' && req.files.length  > 0)
												{
													Promise.all(
														req.files.map(async (file) => {
														const newUpload = new ProductImages({
															name: file.filename,
															image: file.path,
															product: product._id,
														});
													
														return await newUpload.save();
														})
													)
													.then(function(proImage) {
														//console.log(proImage)
														allImages = proImage.map(function(pImg) {
															//console.log(pImg.image)
															pImg.image = constants.urlPath.base+pImg.image;
															return pImg;
														});
														productData.images = allImages; 
														//console.log(allImages);
														//responseArr.push({product:productData,images:allImages})
														//var responseArr1 = {product:productData,images:allImages};
														return apiResponse.successResponseWithData(res,"Product update Success.", productData);
													})
													.catch((e) => {
															//console.log(newUpload)
															return apiResponse.successResponseWithData(res,"Error in product update.");
														});
													
												}
												else
												{

													ProductImages.find({product:req.params.id}).then((productImage)=>{
														if(productImage.length > 0){
															allImages = productImage.map(function(pImg) {
																//console.log(pImg.image)
																pImg.image = constants.urlPath.base+pImg.image;
																return pImg;
															});
															productData.images = allImages; 
															//var responseArr1 = {product:productData,images:allImages};
													
															return apiResponse.successResponseWithData(res,"Product update Success.", productData);
														}else{
															productData.images = []; 
															var responseArr1 = {product:productData,images:[]};
															return apiResponse.successResponseWithData(res,"Product update Success.", productData);
															//return apiResponse.successResponseWithData(res, "Operation success", []);
														}
													});
													
												}
												////////////////// End image upload /////////////////
										  
										  }, reason => {
											return apiResponse.successResponseWithData(res,"Product update Success.", productData);
										  });
										
					
										
									}
								});
							
						}
					});
				}
			}
		} catch (err) {
			//throw error in json response with status 500. 
			return apiResponse.ErrorResponse(res, err);
		}
	}
];

/**
 * Product Delete.
 * 
 * @param {string}      id
 * 
 * @returns {Object}
 */
exports.productDelete = [
	auth,
	function (req, res) {
		if(!mongoose.Types.ObjectId.isValid(req.params.id)){
			return apiResponse.validationErrorWithData(res, "Invalid Error.", "Invalid ID");
		}
		try {
			Product.findById(req.params.id, function (err, foundProduct) {
				if(foundProduct === null){
					return apiResponse.notFoundResponse(res,"Product not exists with this id");
				}else{
					
						Product.findByIdAndRemove(req.params.id,function (err) {
							if (err) { 
								return apiResponse.ErrorResponse(res, err); 
							}else{
								return apiResponse.successResponse(res,"Product delete Success.");
							}
						});
					
				}
			});
		} catch (err) {
			//throw error in json response with status 500. 
			return apiResponse.ErrorResponse(res, err);
		}
	}
];