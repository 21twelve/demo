const ShopCategory = require("../models/ShopCategoryModel");
const Shop = require("../models/ShopModel");
const UserModel = require("../models/UserModel");
const VehicalCategoryModel = require("../models/VehicalCategoryModel");
const CategoryModel = require("../models/CategoryModel");
const { body,validationResult } = require("express-validator");
const { sanitizeBody } = require("express-validator");
const apiResponse = require("../helpers/apiResponse");
const auth = require("../middlewares/jwt");
var mongoose = require("mongoose");
var async = require('async');

mongoose.set("useFindAndModify", false);
const { constants } = require("../helpers/constants");
// Shop Category Schema
function ShopCategoryData(data) {
	this.id = data._id;
	this.name= data.name;
	this.description = data.description;
	this.image = data.image;
	this.createdAt = data.createdAt;
	this.updatedAt = data.updatedAt;
}

/**
 * Shop Category List.
 * 
 * @returns {Object}
 */
exports.utilityList = [
//	auth,
	function (req, res) {
		try {
			var queries = [];	
			var utility = [];	
			queries.push(function (cb) {
				ShopCategory.find().exec(function (err, docs) {
					if (err) {
						throw cb(err);
					}

					// do some stuff with docs & pass or directly pass it
					cb(null, docs);
				});
			})    
			queries.push(function (cb) {
				VehicalCategoryModel.find().exec(function (err, docs) {
					if (err) {
						throw cb(err);
					}

					// do some stuff with docs & pass or directly pass it
					cb(null, docs);
				});
			})  
			queries.push(function (cb) {
				CategoryModel.find().exec(function (err, docs) {
					if (err) {
						throw cb(err);
					}
					var i = 0;
					docs.map(function(pImg) {
						console.log(pImg.image);
						if(typeof pImg.image === 'undefined')
						{
							docs[i].image = '';
						}
						else
						{
							docs[i].image = constants.urlPath.base+pImg.image;
							
						}
						
						i++;
					});
					// do some stuff with docs & pass or directly pass it
					cb(null, docs);
				});
			})  
		} catch (err) {
			//throw error in json response with status 500. 
			return apiResponse.ErrorResponse(res, err);
		}
		
		////////////////////// All query resutl /////////////////
		async.parallel(queries, function(err, docs) {
			// if any query fails
			if (err) {
				return apiResponse.ErrorResponse(res, err);
			}
		//	utility.push(docs[0]); // result of queries[0]
		//	utility.push(docs[1]);
				var onBordingScreen = [] 
				onBordingScreen.push(
					{'title':'Ecolive1','appImage':constants.urlPath.upload_url+'temp1@2x.png','appDescription':'EcoLive is ecommerce plateform step 1'});
					onBordingScreen.push(	{'title':'Ecolive1','appImage':constants.urlPath.upload_url+'temp2@2x.png','appDescription':'EcoLive is ecommerce plateform step 1'});
					onBordingScreen.push({'title':'Ecolive1','appImage':constants.urlPath.upload_url+'temp3@2x.png','appDescription':'EcoLive is ecommerce plateform step 1'});
					let utility = {onBordingScreen:onBordingScreen, shopCategories:docs[0], vehicalCategories:docs[1], productCategories:docs[2]}; 
				// 	utility.push({
				// 	onBordingScreen : onBordingScreen,
				// 	shopCategories: docs[0], 
				// 	vehicalCategories:  docs[1],
				// 	productCategories:  docs[2]
				// });

			return apiResponse.successResponseWithData(res, "Operation success",utility);
		})
		////////////////////// All query resutl end/////////////////
	}
];
/**
 * Shop Detail.
 * 
 * @param {string} id
 * 
 * @returns {Object}
 */
exports.shopDetail = [
	auth,
	function (req, res) {
		if(!mongoose.Types.ObjectId.isValid(req.params.id)){
			return apiResponse.successResponseWithData(res, "Operation success111", {});
		}
		try {
			Shop.findOne({_id: req.params.id,user: req.user._id},"_id user shopName description category address latitude longitude zipCode image createdAt").then((shop)=>{                
				if(shop !== null){
					let shopData = new ShopData(shop);
					return apiResponse.successResponseWithData(res, "Operation success11", shopData);
				}else{
					return apiResponse.successResponseWithData(res, "Operation success11", {});
				}
			});
		} catch (err) {
			//throw error in json response with status 500. 
			return apiResponse.ErrorResponse(res, err);
		}
	}
];

/**
 * Shop store.
 * 
 * @param {string}  shopName 
 * @param {string}  category
 * @param {string}  address
 * @param {string}  latitude
 * @param {string}  longitude
 * @param {string} 	zipCode
 * @param {string} 	description
 * @returns {Object}
 */
exports.shopStore = [
	auth,
	body("shopName", "shopName must not be empty.").isLength({ min: 1 }).trim(),
	body("category", "category must not be empty.").isLength({ min: 1 }).trim(),
	body("address", "address must not be empty.").isLength({ min: 1 }).trim(),
	body("zipCode", "zipCode must not be empty.").isLength({ min: 1 }).trim(),
	body("latitude", "latitude must not be empty.").isLength({ min: 1 }).trim(),
	body("longitude", "longitude must not be empty.").isLength({ min: 1 }).trim(),
	body("description", "Description must not be empty.").isLength({ min: 1 }).trim().custom((value,{req}) => {
		return Shop.findOne({shopName : value,user: req.user._id}).then(shop => {
			if (shop) {
				return Promise.reject("Shop already exist with this shop name.");
			}
		});
	}),
	sanitizeBody("*").escape(),
	(req, res) => {
		try {
			const errors = validationResult(req);
			var shop = new Shop(
				{ 	
					user: req.user,
					shopName: req.body.shopName,
					category: req.body.category,
					address: req.body.address,
					latitude: req.body.latitude,
					longitude: req.body.longitude,
					zipCode : req.body.zipCode,
					description: req.body.description,
				});

			if (!errors.isEmpty()) {
				return apiResponse.validationErrorWithData(res, "Validation Error.", errors.array());
			}
			else {
				//Save shop.
				shop.save(function (err) {
					if (err) { return apiResponse.ErrorResponse(res, err); }
					let shopData = new ShopData(shop);
					return apiResponse.successResponseWithData(res,"Shop add Success.", shopData);
				});
			}
		} catch (err) {
			//throw error in json response with status 500. 
			return apiResponse.ErrorResponse(res, err);
		}
	}
];

/**
 * Shop update.
 * 
 * @param {string}      shopName
 * @param {string}      category
 * @param {string}      zipCode 
 * @param {string}      description
 * @param {string}      address
 * @param {string}      latitude
 * @param {string}      longitude
 
 * 
 * @returns {Object}
 */
exports.shopUpdate = [
	auth,
	body("shopName", "shopName must not be empty.").isLength({ min: 1 }).trim(),
	body("category", "category must not be empty.").isLength({ min: 1 }).trim(),
	body("address", "address must not be empty.").isLength({ min: 1 }).trim(),
	body("latitude", "latitude must not be empty.").isLength({ min: 1 }).trim(),
	body("longitude", "longitude must not be empty.").isLength({ min: 1 }).trim(),
	body("zipCode", "zipCode must not be empty.").isLength({ min: 1 }).trim(),
	body("description", "Description must not be empty.").isLength({ min: 1 }).trim().custom((value,{req}) => {
		return Shop.findOne({isbn : value,user: req.user._id, _id: { "$ne": req.params.id }}).then(shop => {
			if (shop) {
				return Promise.reject("Shop already exist with this ISBN no.");
			}
		});
	}),
	sanitizeBody("*").escape(),
	(req, res) => {
		try {
			const errors = validationResult(req);
			var shop = new Shop(
				{ 
					user: req.user,
					shopName: req.body.shopName,
					description: req.body.description,
					category: req.body.category,
					address: req.body.address,
					latitude: req.body.latitude,
					longitude: req.body.longitude,
					zipCode: req.body.zipCode,
					_id:req.params.id
				});

			if (!errors.isEmpty()) {
				return apiResponse.validationErrorWithData(res, "Validation Error.", errors.array());
			}
			else {
				if(!mongoose.Types.ObjectId.isValid(req.params.id)){
					return apiResponse.validationErrorWithData(res, "Invalid Error.", "Invalid ID");
				}else{
					Shop.findById(req.params.id, function (err, foundShop) {
						if(foundShop === null){
							return apiResponse.notFoundResponse(res,"Shop not exists with this id");
						}else{
							//Check authorized user
							if(foundShop.user.toString() !== req.user._id){
								return apiResponse.unauthorizedResponse(res, "You are not authorized to do this operation.");
							}else{
								//update shop.
								Shop.findByIdAndUpdate(req.params.id, shop, {},function (err) {
									if (err) { 
										return apiResponse.ErrorResponse(res, err); 
									}else{
										let shopData = new ShopData(shop);
										return apiResponse.successResponseWithData(res,"Shop update Success.", shopData);
									}
								});
							}
						}
					});
				}
			}
		} catch (err) {
			//throw error in json response with status 500. 
			return apiResponse.ErrorResponse(res, err);
		}
	}
];

/**
 * Shop Delete.
 * 
 * @param {string}      id
 * 
 * @returns {Object}
 */
exports.shopDelete = [
	auth,
	function (req, res) {
		if(!mongoose.Types.ObjectId.isValid(req.params.id)){
			return apiResponse.validationErrorWithData(res, "Invalid Error.", "Invalid ID");
		}
		try {
			Shop.findById(req.params.id, function (err, foundShop) {
				if(foundShop === null){
					return apiResponse.notFoundResponse(res,"Shop not exists with this id");
				}else{
					//Check authorized user
					if(foundShop.user.toString() !== req.user._id){
						return apiResponse.unauthorizedResponse(res, "You are not authorized to do this operation.");
					}else{
						//delete shop.
						Shop.findByIdAndRemove(req.params.id,function (err) {
							if (err) { 
								return apiResponse.ErrorResponse(res, err); 
							}else{
								return apiResponse.successResponse(res,"Shop delete Success.");
							}
						});
					}
				}
			});
		} catch (err) {
			//throw error in json response with status 500. 
			return apiResponse.ErrorResponse(res, err);
		}
	}
];