const Cart = require("../models/CartModel");
const Product = require("../models/ProductModel");
const Cateogry = require("../models/CategoryModel");
const SubCategory = require("../models/SubCategoryModel");
const Shop = require("../models/ShopModel");
const ProductImages = require("../models/ProductImagesModel");
const { body,validationResult } = require("express-validator");
const { sanitizeBody } = require("express-validator");
const apiResponse = require("../helpers/apiResponse");
const auth = require("../middlewares/jwt");
var mongoose = require("mongoose");
const { constants } = require("../helpers/constants");

mongoose.set("useFindAndModify", false);

// Cart Schema
function CartData(data) {
	this.id = data._id;
	this.shop_id = data.shop_id;
	this.product_id = data.product_id;
	this.user = data.user;
	this.qty = data.qty;
	this.purchase_type = data.purchase_type;
	this.price = data.price;
	this.createdAt = data.createdAt;
}

/**
 * Cart List.
 * 
 * @returns {Object}
 */
exports.cartList = [
	auth,
	function (req, res) {
		try {
			let user_id = mongoose.Types.ObjectId(req.user._id );
			console.log(user_id);
			const cart_qry = [
				// { $match: {category: cart_id } },
			{
				$lookup:{
					from: 'products', 
					localField:'product_id', 
					foreignField:'_id',
					as:'products'
				}
			},
			{$unwind: '$products'},
			{
				$lookup:{
					from: 'productimages', 
					localField:'products._id', 
					foreignField:'product',
					as:'images'
				},
			},
			{$unwind: '$images'},
			{ 
				"$group": {
					"_id": "$_id",
					"user": { "$first": "$user" },
					"shop_id": { "$first": "$shop_id" },
					"product_id": { "$first": "$product_id" },
					"qty": { "$first": "$qty" },
					"purchase_type": { "$first": "$purchase_type" },
					"product_color": { "$first": "$product_color" },
					"createdAt": { "$first": "$createdAt" },
					"updatedAt": { "$first": "$updatedAt" },
					"products": { "$first": "$products" },
					"images": { "$first": "$images" },
					// images: {
					// 		$concat:
					// 		[
					// 		// {$cond:[{$eq:['$image', null]}, "", constants.urlPath.base] },
					// 		{$cond:[{$eq:[{$ifNull:["$images.image",constants.urlPath.base]},constants.urlPath.base]},"",constants.urlPath.base]},
					// 		{$ifNull:["$images.image",""]}
					// 		]
					// 	},
					//"products": { "$first": "$products.online_price" },
					// "ptotal": { "$sum": "$products.live_price" },
					// products: {
					// 	$push: {
					// 		name: "$products.name",
					// 	}
					// },

					// images: {
					// 	$push: {
					// 		_id: "$images._id",
					// 		name: "$images.name",
					// 		image: "$images.image",
					// 		product: "$images.product",
					// 		createdAt: "$images.createdAt",
					// 		updatedAt: "$images.updatedAt",
					// 		image:  {$concat:[constants.urlPath.base, "$images.image"]},
							
					// 	}
					// }      
				}
			},
				{
					$project: { 
						user:1,
						shop_id:1,
						product_id:1,
						qty:1,
						purchase_type:1,
						product_color:1,
						createdAt:1,
						updatedAt:1,
						product_name : "$products.name",
						live_price : "$products.live_price",
						online_price : "$products.online_price",
						//products: "$products",
						//products: "$products",
						//images: "$images",
						product_image: {
							$concat:
							[
							// {$cond:[{$eq:['$image', null]}, "", constants.urlPath.base] },
							{$cond:[{$eq:[{$ifNull:["$images.image",constants.urlPath.base]},constants.urlPath.base]},"",constants.urlPath.base]},
							{$ifNull:["$images.image",""]}
							]
						},
					//	image:{$concat:[constants.urlPath.base]}
					}
				},
			{ $facet : {payload : [ { $skip: 0 }, {$limit: 100 } ] } }
			]
			if (user_id) {
				cart_qry.unshift({ $match: {user: user_id} });
			}
			Cart.aggregate(cart_qry).exec((err, result)=>{
				if (err) {
					//console.log("error" ,err)
					return apiResponse.ErrorResponse(res, err);
				}
				if (result) {
					//console.log(result);
					return apiResponse.successResponseWithData(res,"Opration successfully.", result[0].payload);

				}
			});
		} catch (err) {
			//throw error in json response with status 500. 
			return apiResponse.ErrorResponse(res, err);
		}
	}
];

/**
 * Cart store.
 * 
 * @param {string}  shopId 
 * @param {string}  productId
 * @param {string}  userId
 * @param {string}  qty
 * @returns {Object}
 */
exports.cartStore = [
	auth,
	body("shop_id", "Shop must not be empty.").isLength({ min: 1 }).trim(),
	body("qty", "qty must not be empty.").isLength({ min: 1 }).trim(),
	body("product_id", "Product must not be empty.").isLength({ min: 1 }).trim().custom((value,{req}) => {
		console.log('value',value);
		return Cart.findOne({product_id : value,user: req.user._id}).then(cart => {
			if (cart) {
				return Promise.reject("Product already exist in you cart.");
			}
		});
	}),
	sanitizeBody("*").escape(),
	(req, res) => {
		try {
			const errors = validationResult(req);
			var cart = new Cart(
				{	
					shop_id: req.body.shop_id,
					product_id: req.body.product_id,
					qty: req.body.qty,
					purchase_type:req.body.purchase_type,
					product_color:req.body.product_color,
					user: req.user,
				});
				console.log(cart);
			if (!errors.isEmpty()) {
				return apiResponse.validationErrorWithData(res, "Validation Error.", errors.array());
			}
			else {
				//Save shop.
				
				cart.save(function (err) {
					if (err) { return apiResponse.ErrorResponse(res, err); }
					//let cartData = new CartData(cart);

					console.log('cart._id-------',cart._id);
					let cart_id = mongoose.Types.ObjectId(cart._id);
					
					const cart_qry = [
						// { $match: {category: cart_id } },
					{
						$lookup:{
							from: 'products', 
							localField:'product_id', 
							foreignField:'_id',
							as:'products'
						}
					},
					{$unwind: '$products'},
					{
						$lookup:{
							from: 'productimages', 
							localField:'products._id', 
							foreignField:'product',
							as:'images'
						},
					},
					{$unwind: '$images'},
					{ 
						"$group": {
							"_id": "$_id",
							"user": { "$first": "$user" },
							"shop_id": { "$first": "$shop_id" },
							"product_id": { "$first": "$product_id" },
							"qty": { "$first": "$qty" },
							"purchase_type": { "$first": "$purchase_type" },
							"product_color": { "$first": "$product_color" },
							"createdAt": { "$first": "$createdAt" },
							"updatedAt": { "$first": "$updatedAt" },
							"products": { "$first": "$products" },
							"images": { "$first": "$images" },
							// images: {
							// 		$concat:
							// 		[
							// 		// {$cond:[{$eq:['$image', null]}, "", constants.urlPath.base] },
							// 		{$cond:[{$eq:[{$ifNull:["$images.image",constants.urlPath.base]},constants.urlPath.base]},"",constants.urlPath.base]},
							// 		{$ifNull:["$images.image",""]}
							// 		]
							// 	},
							//"products": { "$first": "$products.online_price" },
							// "ptotal": { "$sum": "$products.live_price" },
							// products: {
							// 	$push: {
							// 		name: "$products.name",
							// 	}
							// },

							// images: {
							// 	$push: {
							// 		_id: "$images._id",
							// 		name: "$images.name",
							// 		image: "$images.image",
							// 		product: "$images.product",
							// 		createdAt: "$images.createdAt",
							// 		updatedAt: "$images.updatedAt",
							// 		image:  {$concat:[constants.urlPath.base, "$images.image"]},
									
							// 	}
							// }      
						}
					},
						{
							$project: { 
								user:1,
								shop_id:1,
								product_id:1,
								qty:1,
								purchase_type:1,
								product_color:1,
								createdAt:1,
								updatedAt:1,
								product_name : "$products.name",
								live_price : "$products.live_price",
								online_price : "$products.online_price",
								//products: "$products",
								//products: "$products",
								//images: "$images",
								product_image: {
									$concat:
									[
									// {$cond:[{$eq:['$image', null]}, "", constants.urlPath.base] },
									{$cond:[{$eq:[{$ifNull:["$images.image",constants.urlPath.base]},constants.urlPath.base]},"",constants.urlPath.base]},
									{$ifNull:["$images.image",""]}
									]
								},
							//	image:{$concat:[constants.urlPath.base]}
							}
						},
					{ $facet : {payload : [ { $skip: 0 }, {$limit: 100 } ] } }
					]
					if (cart_id) {
						cart_qry.unshift({ $match: {_id: cart_id } });
					}
					Cart.aggregate(cart_qry).exec((err, result)=>{
						if (err) {
							//console.log("error" ,err)
							return apiResponse.ErrorResponse(res, err);
						}
						if (result) {
							//console.log(result);
							return apiResponse.successResponseWithData(res,"Product added in your cart successfully.", result[0].payload[0]);

						}
					});
					//return apiResponse.successResponseWithData(res,"Product add Success in your cart.", cartData);
				});
			}
		} catch (err) {
			//throw error in json response with status 500. 
			return apiResponse.ErrorResponse(res, err);
		}
	}
];

/**
 * Cart update.
 * 
 * @param {string}  shopId 
 * @param {string}  productId
 * @param {string}  userId
 * @param {string}  qty
 * @returns {Object}
 
 * 
 * @returns {Object}
 */
exports.cartUpdate = [
	auth,
	body("product_id", "Product must not be empty.").isLength({ min: 1 }).trim(),
	body("shop_id", "Shop must not be empty.").isLength({ min: 1 }).trim(),
	body("qty", "qty must not be empty.").isLength({ min: 1 }).trim().custom((value,{req}) => {
		return Cart.findOne({productId : value,user: req.user._id, _id: { "$ne": req.params.id }}).then(cart => {
			if (cart) {
				return Promise.reject("Product already exist in your cart.");
			}
		});
	}),
	sanitizeBody("*").escape(),
	(req, res) => {
		try {
			const errors = validationResult(req);
			var cart = new Cart(
				{ 
					shop_id: req.body.shop_id,
					product_id: req.body.product_id,
					qty: req.body.qty,
					user: req.user,
					purchase_type:req.body.purchase_type,
					product_color:req.body.product_color,
					_id:req.params.id
				});
console.log(cart);
			if (!errors.isEmpty()) {
				return apiResponse.validationErrorWithData(res, "Validation Error.", errors.array());
			}
			else {
				if(!mongoose.Types.ObjectId.isValid(req.params.id)){
					return apiResponse.validationErrorWithData(res, "Invalid Error.", "Invalid ID");
				}else{
					Cart.findById(req.params.id, function (err, foundCart) {
						if(foundCart === null){
							return apiResponse.notFoundResponse(res,"Product not exists with this id");
						}else{
							//Check authorized user
							if(foundCart.user.toString() !== req.user._id){
								return apiResponse.unauthorizedResponse(res, "You are not authorized to do this operation.");
							}else{
								//update shop.
								Cart.findByIdAndUpdate(req.params.id, cart, {},function (err) {
									if (err) { 
										return apiResponse.ErrorResponse(res, err); 
									}else{
										let cart_id = mongoose.Types.ObjectId(req.params.id);
					
										const cart_qry = [
											// { $match: {category: cart_id } },
										{
											$lookup:{
												from: 'products', 
												localField:'product_id', 
												foreignField:'_id',
												as:'products'
											}
										},
										{$unwind: '$products'},
										{
											$lookup:{
												from: 'productimages', 
												localField:'products._id', 
												foreignField:'product',
												as:'images'
											},
										},
										{$unwind: '$images'},
										{ 
											"$group": {
												"_id": "$_id",
												"user": { "$first": "$user" },
												"shop_id": { "$first": "$shop_id" },
												"product_id": { "$first": "$product_id" },
												"qty": { "$first": "$qty" },
												"purchase_type": { "$first": "$purchase_type" },
												"product_color": { "$first": "$product_color" },
												"createdAt": { "$first": "$createdAt" },
												"updatedAt": { "$first": "$updatedAt" },
												"products": { "$first": "$products" },
												"images": { "$first": "$images" },
												// images: {
												// 		$concat:
												// 		[
												// 		// {$cond:[{$eq:['$image', null]}, "", constants.urlPath.base] },
												// 		{$cond:[{$eq:[{$ifNull:["$images.image",constants.urlPath.base]},constants.urlPath.base]},"",constants.urlPath.base]},
												// 		{$ifNull:["$images.image",""]}
												// 		]
												// 	},
												//"products": { "$first": "$products.online_price" },
												// "ptotal": { "$sum": "$products.live_price" },
												// products: {
												// 	$push: {
												// 		name: "$products.name",
												// 	}
												// },

												// images: {
												// 	$push: {
												// 		_id: "$images._id",
												// 		name: "$images.name",
												// 		image: "$images.image",
												// 		product: "$images.product",
												// 		createdAt: "$images.createdAt",
												// 		updatedAt: "$images.updatedAt",
												// 		image:  {$concat:[constants.urlPath.base, "$images.image"]},
														
												// 	}
												// }      
											}
										},
											{
												$project: { 
													user:1,
													shop_id:1,
													product_id:1,
													qty:1,
													purchase_type:1,
													createdAt:1,
													updatedAt:1,
													product_color : 1,
													product_name : "$products.name",
													live_price : "$products.live_price",
													online_price : "$products.online_price",
													//products: "$products",
													//products: "$products",
													//images: "$images",
													product_image: {
														$concat:
														[
														// {$cond:[{$eq:['$image', null]}, "", constants.urlPath.base] },
														{$cond:[{$eq:[{$ifNull:["$images.image",constants.urlPath.base]},constants.urlPath.base]},"",constants.urlPath.base]},
														{$ifNull:["$images.image",""]}
														]
													},
												//	image:{$concat:[constants.urlPath.base]}
												}
											},
										{ $facet : {payload : [ { $skip: 0 }, {$limit: 100 } ] } }
										]
										if (cart_id) {
											cart_qry.unshift({ $match: {_id: cart_id } });
										}
										Cart.aggregate(cart_qry).exec((err, result)=>{
											if (err) {
												//console.log("error" ,err)
												return apiResponse.ErrorResponse(res, err);
											}
											if (result) {
												//console.log(result);
												return apiResponse.successResponseWithData(res,"Cart updated successfully.", result[0].payload[0]);
					
											}
										});
									}
								});
							}
						}
					});
				}
			}
		} catch (err) {
			//throw error in json response with status 500. 
			return apiResponse.ErrorResponse(res, err);
		}
	}
];

/**
 * Cart Delete.
 * 
 * @param {string}      id
 * 
 * @returns {Object}
 */
exports.cartDelete = [
	auth,
	function (req, res) {
		if(!mongoose.Types.ObjectId.isValid(req.params.id)){
			return apiResponse.validationErrorWithData(res, "Invalid Error.", "Invalid ID");
		}
		try {
			Cart.findById(req.params.id, function (err, foundCart) {
				if(foundCart === null){
					return apiResponse.notFoundResponse(res,"Product not exists with this id");
				}else{
					//Check authorized user
					if(foundCart.user.toString() !== req.user._id){
						return apiResponse.unauthorizedResponse(res, "You are not authorized to do this operation.");
					}else{
						//delete shop.
						Cart.findByIdAndRemove(req.params.id,function (err) {
							if (err) { 
								return apiResponse.ErrorResponse(res, err); 
							}else{
								return apiResponse.successResponse(res,"Product delete from in your cart success.");
							}
						});
					}
				}
			});
		} catch (err) {
			//throw error in json response with status 500. 
			return apiResponse.ErrorResponse(res, err);
		}
	}
];

/**
 * Cart Delete.
 * 
 * @param {string}      id
 * 
 * @returns {Object}
 */
 exports.cartDeleteAll = [
	auth,
	function (req, res) {
		// if(!mongoose.Types.ObjectId.isValid(req.params.id)){
		// 	return apiResponse.validationErrorWithData(res, "Invalid Error.", "Invalid ID");
		// }
		try {
			Cart.findOne({user:req.user._id}, function (err, foundCart) {
				if(foundCart === null){
					return apiResponse.notFoundResponse(res,"Product not exists with this id");
				}else{
					//Check authorized user
					if(foundCart.user.toString() !== req.user._id){
						return apiResponse.unauthorizedResponse(res, "You are not authorized to do this operation.");
					}else{
						//delete shop.
						Cart.remove({user:req.user._id},function (err) {
							if (err) { 
								return apiResponse.ErrorResponse(res, err); 
							}else{
								return apiResponse.successResponse(res,"Product delete from in your cart success.");
							}
						});
					}
				}
			});
		} catch (err) {
			//throw error in json response with status 500. 
			return apiResponse.ErrorResponse(res, err);
		}
	}
];