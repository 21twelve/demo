const Vehical = require("../models/VehicalModel");
const { body,validationResult } = require("express-validator");
const { sanitizeBody } = require("express-validator");
const apiResponse = require("../helpers/apiResponse");
const auth = require("../middlewares/jwt");
var mongoose = require("mongoose");
const { constants } = require("../helpers/constants");

mongoose.set("useFindAndModify", false);

// Vehical Schema
function VehicalData(data) {
	this.id = data._id;
	this.vehicalName= data.vehicalName;
	this.description = data.description;
	this.category = data.category;
	this.address = data.address;
	this.latitude = data.latitude;
	this.longitude = data.longitude;
	this.zipCode = data.zipCode;
	this.image = data.image;
	this.createdAt = data.createdAt;
}

/**
 * Vehical List.
 * 
 * @returns {Object}
 */
exports.vehicalList = [
	auth,
	function (req, res) {
		try {
			let user_id = mongoose.Types.ObjectId(req.body.user_id);
			console.log(user_id);
			Vehical.find({user:user_id},"_id user vehicalName description category address latitude longitude zipCode image createdAt").then((vehicals)=>{
				if(vehicals.length > 0){
					var i = 0;
					vehicals.forEach(function(vehical) {
						if(typeof vehical.image === 'undefined')
						{
							vehicals[i].image = '';
						}
						else
						{
							vehicals[i].image = constants.urlPath.base+vehical.image;
						}
						i++;
						//console.log(shop.image);
					});
					return apiResponse.successResponseWithData(res, "Operation success", vehicals);
				}else{
					return apiResponse.successResponseWithData(res, "Operation success", []);
				}
			});
		} catch (err) {
			//throw error in json response with status 500. 
			return apiResponse.ErrorResponse(res, err);
		}
	}
];

/**
 * Vehical Detail.
 * 
 * @param {string} id
 * 
 * @returns {Object}
 */
exports.vehicalDetail = [
	auth,
	function (req, res) {
		
		if(!mongoose.Types.ObjectId.isValid(req.params.id)){
			return apiResponse.successResponseWithData(res, "Operation success111", {});
		}
		try {
			Vehical.findOne({_id: req.params.id,user: req.user._id},"_id user vehicalName description category address latitude longitude zipCode image createdAt").then((vehical)=>{                
				if(vehical !== null){
					let vehicalData = new VehicalData(vehical);
					return apiResponse.successResponseWithData(res, "Operation success11", vehicalData);
				}else{
					return apiResponse.successResponseWithData(res, "Operation success11", {});
				}
			});
		} catch (err) {
			//throw erro in json response with status 500. 
			return apiResponse.ErrorResponse(res, err);
		}
	}
];

/**
 * Vehical store.
 * 
 * @param {string}  vehicalName 
 * @param {string}  category
 * @param {string}  address
 * @param {string}  latitude
 * @param {string}  longitude
 * @param {string} 	zipCode
 * @param {string} 	description
 * @returns {Object}
 */
exports.vehicalStore = [
	auth,
	body("vehicalName", "vehicalName must not be empty.").isLength({ min: 1 }).trim(),
	body("category", "category must not be empty.").isLength({ min: 1 }).trim(),
	body("address", "address must not be empty.").isLength({ min: 1 }).trim(),
	body("zipCode", "zipCode must not be empty.").isLength({ min: 1 }).trim(),
	body("latitude", "latitude must not be empty.").isLength({ min: 1 }).trim(),
	body("longitude", "longitude must not be empty.").isLength({ min: 1 }).trim(),
	body("description", "Description must not be empty.").isLength({ min: 1 }).trim().custom((value,{req}) => {
		return Vehical.findOne({vehicalName : value,user: req.user._id}).then(vehical => {
			if (vehical) {
				return Promise.reject("Vehical already exist with this vehical name.");
			}
		});
	}),
	sanitizeBody("*").escape(),
	(req, res) => {
		try {
			const errors = validationResult(req);
			var vehical = new Vehical(
				{ 	
					user: req.user,
					vehicalName: req.body.vehicalName,
					category: req.body.category,
					address: req.body.address,
					latitude: req.body.latitude,
					longitude: req.body.longitude,
					zipCode : req.body.zipCode,
					description: req.body.description,
					image: req.file.path,
				});

			if (!errors.isEmpty()) {
				return apiResponse.validationErrorWithData(res, "Validation Error.", errors.array());
			}
			else {
				//Save vehical.
				vehical.save(function (err) {
					if (err) { return apiResponse.ErrorResponse(res, err); }
					let vehicalData = new VehicalData(vehical);
					return apiResponse.successResponseWithData(res,"Vehical add Success.", vehicalData);
				});
			}
		} catch (err) {
			//throw error in json response with status 500. 
			return apiResponse.ErrorResponse(res, err);
		}
	}
];

/**
 * Vehical update.
 * 
 * @param {string}      vehicalName
 * @param {string}      category
 * @param {string}      zipCode 
 * @param {string}      description
 * @param {string}      address
 * @param {string}      latitude
 * @param {string}      longitude
 
 * 
 * @returns {Object}
 */
exports.vehicalUpdate = [
	auth,
	body("vehicalName", "vehicalName must not be empty.").isLength({ min: 1 }).trim(),
	body("category", "category must not be empty.").isLength({ min: 1 }).trim(),
	// body("address", "address must not be empty.").isLength({ min: 1 }).trim(),
	// body("latitude", "latitude must not be empty.").isLength({ min: 1 }).trim(),
	// body("longitude", "longitude must not be empty.").isLength({ min: 1 }).trim(),
	// body("zipCode", "zipCode must not be empty.").isLength({ min: 1 }).trim(),
	// body("description", "Description must not be empty.").isLength({ min: 1 }).trim().custom((value,{req}) => {
	// 	return Vehical.findOne({isbn : value,user: req.user._id, _id: { "$ne": req.params.id }}).then(vehical => {
	// 		if (vehical) {
	// 			return Promise.reject("Vehical already exist with this ISBN no.");
	// 		}
	// 	});
	// }),
	sanitizeBody("*").escape(),
	(req, res) => {
		try {
			const errors = validationResult(req);
			var vehical = new Vehical(
				{ 
					user: req.user,
					vehicalName: req.body.vehicalName,
					description: req.body.description,
					category: req.body.category,
					address: req.body.address,
					latitude: req.body.latitude,
					longitude: req.body.longitude,
					zipCode: req.body.zipCode,
					image: req.file.path,
					_id:req.params.id
				});

			if (!errors.isEmpty()) {
				return apiResponse.validationErrorWithData(res, "Validation Error.", errors.array());
			}
			else {
				if(!mongoose.Types.ObjectId.isValid(req.params.id)){
					return apiResponse.validationErrorWithData(res, "Invalid Error.", "Invalid ID");
				}else{
					Vehical.findById(req.params.id, function (err, foundVehical) {
						if(foundVehical === null){
							return apiResponse.notFoundResponse(res,"Vehical not exists with this id");
						}else{
							//Check authorized user
							if(foundVehical.user.toString() !== req.user._id){
								return apiResponse.unauthorizedResponse(res, "You are not authorized to do this operation.");
							}else{
								//update vehical.
								Vehical.findByIdAndUpdate(req.params.id, vehical, {},function (err) {
									if (err) { 
										return apiResponse.ErrorResponse(res, err); 
									}else{
										let vehicalData = new VehicalData(vehical);
										vehicalData.image = constants.urlPath.base+vehicalData.image;
										return apiResponse.successResponseWithData(res,"Vehical update Success.", vehicalData);
									}
								});
							}
						}
					});
				}
			}
		} catch (err) {
			//throw error in json response with status 500. 
			return apiResponse.ErrorResponse(res, err);
		}
	}
];

/**
 * Vehical Delete.
 * 
 * @param {string}      id
 * 
 * @returns {Object}
 */
exports.vehicalDelete = [
	auth,
	function (req, res) {
		if(!mongoose.Types.ObjectId.isValid(req.params.id)){
			return apiResponse.validationErrorWithData(res, "Invalid Error.", "Invalid ID");
		}
		try {
			Vehical.findById(req.params.id, function (err, foundVehical) {
				if(foundVehical === null){
					return apiResponse.notFoundResponse(res,"Vehical not exists with this id");
				}else{
					//Check authorized user
					if(foundVehical.user.toString() !== req.user._id){
						return apiResponse.unauthorizedResponse(res, "You are not authorized to do this operation.");
					}else{
						//delete vehical.
						Vehical.findByIdAndRemove(req.params.id,function (err) {
							if (err) { 
								return apiResponse.ErrorResponse(res, err); 
							}else{
								return apiResponse.successResponse(res,"Vehical delete Success.");
							}
						});
					}
				}
			});
		} catch (err) {
			//throw error in json response with status 500. 
			return apiResponse.ErrorResponse(res, err);
		}
	}
];