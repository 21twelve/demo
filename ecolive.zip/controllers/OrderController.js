const Order = require("../models/OrderModel");
const OrderChild = require("../models/OrderChildModel");
const Transaction = require("../models/TransactionModel");
const Cart = require("../models/CartModel");
const Product = require("../models/ProductModel");
const Cateogry = require("../models/CategoryModel");
const SubCategory = require("../models/SubCategoryModel");
const Shop = require("../models/ShopModel");
const { body,validationResult } = require("express-validator");
const { sanitizeBody } = require("express-validator");
const apiResponse = require("../helpers/apiResponse");
const auth = require("../middlewares/jwt");
var mongoose = require("mongoose");
mongoose.set("useFindAndModify", false);
const { constants } = require("../helpers/constants");
const payment = require("../helpers/payment");

// var Publishable_Key = 'Your_Publishable_Key'
// var Secret_Key = 'Your_Secret_Key'
// const stripe = require('stripe')(Secret_Key)



const Lookups = require("twilio/lib/rest/Lookups");


// Order Schema
function OrderData(data) {
	this.id = data._id;
	this.user = data.user;
	this.shop = data.shopId;
	this.product = data.productId;
	this.userType = data.userType;
	this.description = data.description;
	this.address = data.address;
	this.latitude = data.latitude;
	this.longitude = data.longitude;
	this.zipCode = data.zipCode;
	this.contactNo = data.contactNo;
	this.orderStatus = data.orderStatus;
	this.updatedAt = data.updatedAt;
	this.createdAt = data.createdAt;
}

exports.orderList1 = [
	async function (req, res) {
		try {
			//const stripe = require('stripe')('sk_test_4eC39HqLyjWDarjtT1zdp7dc');
			var token = await payment.createToken();
			if(token !== null)
			{
				// const token = await stripe.tokens.create({
				// 	card: {
				// 		number: '4242424242424242',
				// 		exp_month: 9,
				// 		exp_year: 2022,
				// 		cvc: '314',
				// 	},
				// });
				
				console.log('token----------',token);
				const charge = await payment.makePayment(token);

				return apiResponse.successResponseWithData(res,"Your order successfully.", charge);
					
			}
		
			//return charge;
				  
			
			//console.log(token);
		}
	   catch (err) {
		   //throw error in json response with status 500. 
		   return apiResponse.ErrorResponse(res, err);
	   }
	}
];
/**
 * Order List.
 * 
 * @returns {Object}
 */
exports.orderList = [
	auth,
	function (req, res) {
		try {

			let user_id = mongoose.Types.ObjectId(req.user._id);
			console.log(user_id);
			//let order_id = mongoose.Types.ObjectId(order_id_root);
		//	console.log('aaaaaaaaaaaaaa----',order_id);
			const order_qry = [
				// { $match: {category: cart_id } },
			{
				$lookup:{
					from: 'orderchildren', 
					localField:'_id', 
					foreignField:'order_id',
					as:'orderchilds'
				}
			},
			{$unwind: '$orderchilds'},
			{
				$lookup:{
					from: 'products', 
					localField:'orderchilds.product_id', 
					foreignField:'_id',
					as:'products'
				}
			},
				{$unwind: '$products'},
			{
				$lookup:{
					from: 'productimages', 
					localField:'products._id', 
					foreignField:'product',
					as:'images'
				},
			},
			{$unwind: '$images'},
			{ 
				"$group": {
					"_id": "$products._id",
					"user": { "$first": "$user" },
					"shop_id": { "$first": "$shop_id" },
					"orderchilds":{ "$first": "$orderchilds" },
					// "product_id": { "$first": "$product_id" },
					// "userType": { "$first": "$userType" },
					// "address": { "$first": "$address" },
					// "latitude": { "$first": "$latitude" },
					// "longitude": { "$first": "$longitude" },
					// "zipCode": { "$first": "$zipCode" },
					// "contactNo": { "$first": "$contactNo" },
					// "description": { "$first": "$description" },
					// "paymentType": { "$first": "$paymentType" },
					// "paymentStatus": { "$first": "$paymentStatus" },
					// "createdAt": { "$first": "$createdAt" },
					// "updatedAt": { "$first": "$updatedAt" },
						"products": { "$first": "$products" },
						"images": { "$first": "$images" },     
				}
			},
				{
					 $project: {
						user:1,
						shop_id:1,
						product_id : "$orderchilds.product_id",
						qty : "$orderchilds.qty",
						// product_id:1,
						// userType:1,
						// address:1,
						// latitude:1,
						// longitude:1,
						// zipCode:1,
						// contactNo:1,
						// description:1,
						// paymentType:1,
						// paymentStatus:1,
						// createdAt:1,
						// updatedAt:1,
							product_name : "$products.name",
						// live_price : "$products.live_price",
						// online_price : "$products.online_price",
						product_image: {
							$concat:
							[
							// {$cond:[{$eq:['$image', null]}, "", constants.urlPath.base] },
							{$cond:[{$eq:[{$ifNull:["$images.image",constants.urlPath.base]},constants.urlPath.base]},"",constants.urlPath.base]},
							{$ifNull:["$images.image",""]}
							]
						},
						//image:{$concat:[constants.urlPath.base]}
					}
				},
			{ $facet : {payload : [ { $skip: 0 }, {$limit: 100 } ] } }
			]
			if (user_id) {
				order_qry.unshift({ $match: {user: user_id } });
			}
			Order.aggregate(order_qry).exec((err, result)=>{
				if (err) {
					//console.log("error" ,err)
					return apiResponse.ErrorResponse(res, err);
				}
				if (result) {
					//console.log(result);
					return apiResponse.successResponseWithData(res,"Your order successfully.", result);

				}
			});	
		} catch (err) {
			//throw error in json response with status 500. 
			return apiResponse.ErrorResponse(res, err);
		}
	}
];

/**
 * Shop Detail.
 * 
 * @param {string} id
 * 
 * @returns {Object}
 */
exports.orderDetail = [
	auth,
	function (req, res) {
		if(!mongoose.Types.ObjectId.isValid(req.params.id)){
			return apiResponse.successResponseWithData(res, "Operation success111", {});
		}
		try {
			Orders.findOne({_id: req.params.id,user: req.user._id},"_id shopName description category address latitude longitude zipCode createdAt").then((shop)=>{                
				if(shop !== null){
					let shopData = new ShopData(shop);
					return apiResponse.successResponseWithData(res, "Operation success11", shopData);
				}else{
					return apiResponse.successResponseWithData(res, "Operation success11", {});
				}
			});
		} catch (err) {
			//throw error in json response with status 500. 
			return apiResponse.ErrorResponse(res, err);
		}
	}
];

/**
 * Shop store.
 * 
 * @param {string}  shopName 
 * @param {string}  category
 * @param {string}  address
 * @param {string}  latitude
 * @param {string}  longitude
 * @param {string} 	zipCode
 * @param {string} 	description
 * @returns {Object}
 */
exports.orderStore = [
	auth,
	body("userType", "User type must not be empty.").isLength({ min: 1 }).trim(),
	body("paymentType", "Payment Type type must not be empty.").isLength({ min: 1 }).trim(),
	body("paymentStatus", "Payment Status type must not be empty.").isLength({ min: 1 }).trim(),
	body("shop_id", "Shop must not be empty.").isLength({ min: 1 }).trim(),
	body("address", "address must not be empty.").isLength({ min: 1 }).trim(),
	body("zipCode", "zipCode must not be empty.").isLength({ min: 1 }).trim(),
	body("latitude", "latitude must not be empty.").isLength({ min: 1 }).trim(),
	body("longitude", "longitude must not be empty.").isLength({ min: 1 }).trim(),
	sanitizeBody("*").escape(),
	 (req, res) => {
		try {
			
			const errors = validationResult(req);
			var totalAmount = 0; 
			var user_id = 0; 
			/////////////////// Cart data get ///////////////////////////////////
			const promiseA = new Promise(function(resolve, reject) {
				Cart.findOne({user:req.user._id}, function (err, foundCart) {
					if(foundCart === null){
						return apiResponse.notFoundResponse(res,"Your order is empty!");
					}else{
						var orderArr = [];
						var i = 0;
						user_id = mongoose.Types.ObjectId(req.user._id);
						const cart_qry = [
							// { $match: {category: req.user._id } },
							//{ $group: { _id: null, amount: { $sum: "$live_price" } } },
							{
								$lookup:{
								from: 'products', 
								localField:'product_id', 
								foreignField:'_id',
								as:'products'
							}
						},
						{$unwind: '$products'},
							{
								$project: { 
									product_id:1,
									qty:1,
									product_color: 1,
									purchase_type: 1,
									shop_id:1,
									product : "$products._id",
									online_price : "$products.online_price",
									live_price : "$products.live_price",
									// "totalPrice": {
									// 	"$subtract": [ "$products.live_price", "$products.qty" ]
									// },
									
								}
							  },
						{ $facet : {payload : [ { $skip: 0 } ] } }
						]
						if (user_id) {
							cart_qry.unshift({ $match: {user: user_id} });
						}
						Cart.aggregate(cart_qry).exec((err, result)=>{
							if (err) {
								//console.log("error" ,err)
								return apiResponse.ErrorResponse(res, err);
							}
							if (result) {
								//console.log('Hereere---------------',result[0].payload);
								const foundCart = result[0].payload;
								// Sum of order item and qty
								foundCart.map(function(proRow) {
									var purchase_price = proRow.purchase_type == 'online' ? proRow.online_price : proRow.live_price;
									totalAmount = (purchase_price * proRow.qty)+totalAmount;
								});
								////////////////// Add order root ////////////////
								var order = new Order(
									{ 	
										shop_id: req.body.shop_id,
										user: req.user,
										userType: req.body.userType,
										address: req.body.address,
										latitude: req.body.latitude,
										longitude: req.body.longitude,
										zipCode : req.body.zipCode,
										contactNo: req.body.contactNo,
										description: req.body.description,
										paymentType:req.body.paymentType,
										paymentStatus:req.body.paymentStatus,
										total_amount:totalAmount,
										orderStatus: 'Placed',
									});
									
								if (!errors.isEmpty()) {
									return apiResponse.validationErrorWithData(res, "Validation Error.", errors.array());
								}
								else {
									order.save(function (err) {
										if (err) { return apiResponse.ErrorResponse(res, err); }
										
										//console.log(result[0].payload)
										//const foundCart = result[0].payload;
										
										allProducts = foundCart.map(function(proRow) {

											//var purchase_price = proRow.purchase_type == 'online' ? proRow.online_price : proRow.live_price;
											//totalAmount = (purchase_price * proRow.qty)+totalAmount;
											var purchase_price = proRow.purchase_type == 'online' ? proRow.online_price : proRow.live_price;
											return {"order_id":order._id,"shop_id": proRow.shop_id,"product_id": proRow.product_id,"qty": proRow.qty,"purchase_type": proRow.purchase_type,"product_color": proRow.product_color,"purchase_price":purchase_price};
											i++;
											return orderArr;
										});
										resolve(allProducts);
									});
								}
								////////////////////////////
								//return apiResponse.successResponseWithData(res,"Subcategory Success.", result[0].payload);
			
							}
						});
					}
				});
			});
			//////////////////// Select cart query end///////////////////////
			promiseA.then(value => {
				//value.push({ quantity: 1 });
				console.log('Order Total ---------- ',totalAmount);
				
				if (value === false) {
					return apiResponse.validationErrorWithData(res, "Validation Error.", errors.array());
				}
				else {
					//Save order.
					OrderChild.insertMany(value,function (err,docs) {
						if (err) { return apiResponse.ErrorResponse(res, err); }
						//console.log(docs);
						var order_id_root = docs[0].order_id;
						//let orderData = new OrderData(order);
						//OrderChild.insertMany(arr, function(error, docs) {})
						///////// Stripe payment start ///////////

						const promiseB = new Promise(function(resolve, reject) {
							
							if(typeof req.body.stripe_token != 'undefined' && req.body.stripe_token != '')
							{
								async function asyncCallPayment() {
									var token = await payment.createToken();
									if(token !== null)
									{
										//console.log('token----------',token);
										const charge = await payment.makePayment(token);
										resolve(charge);
									}
								}
								asyncCallPayment();

								
							}
						});
						///////// Stripe payment end ///////////
						
						promiseB.then(value => {
							console.log('Payment response----',value);
							let order_id = mongoose.Types.ObjectId(order_id_root);
							console.log('aaaaaaaaaaaaaa----',order_id);
							if(typeof value.status != 'undefined' && value.status == 'succeeded')
							{
								var payment_id = value.id; // payment id
								var payment_object = value.object //ex (charge)
								var payment_transaction = value.balance_transaction;//balance_transaction
								var payment_status = value.status;

								var transaction = new Transaction({
									transaction_id:payment_id,
									trnsaction_from:user_id,
									//trnsaction_to:"",
									order:order_id,
									transaction_type:"order",
									amount:totalAmount,
									paymentType:"",
									paymentStatus:payment_status,
									transaction_details:value
								});
								transaction.save(function (err) {
									if (err) { return apiResponse.ErrorResponse(res, err); }

										console.log('transaction history save obj---------------',res)
										var order = new Order(
											{ 	
												_id:order_id,
												paymentStatus: payment_status,
										});
										Order.findByIdAndUpdate(order_id, order, {},function (err) {
											if (err) { 
												return apiResponse.ErrorResponse(res, err); 
											}else{
												console.log('Order update after transaction obj---------------',res)
												//////////// Select start///////////
												const order_qry = [
													// { $match: {category: cart_id } },
												{
													$lookup:{
														from: 'orderchildren', 
														localField:'_id', 
														foreignField:'order_id',
														as:'orderchilds'
													}
												},
												{$unwind: '$orderchilds'},
												{
													$lookup:{
														from: 'products', 
														localField:'orderchilds.product_id', 
														foreignField:'_id',
														as:'products'
													}
												},
												{$unwind: '$products'},
												{
													$lookup:{
														from: 'productimages', 
														localField:'products._id', 
														foreignField:'product',
														as:'images'
													},
												},
												{$unwind: '$images'},
												{ 
													"$group": {
														"_id": "$products._id",
														"user": { "$first": "$user" },
														"shop_id": { "$first": "$shop_id" },
														"orderchilds":{ "$first": "$orderchilds" },
														// "product_id": { "$first": "$product_id" },
														// "userType": { "$first": "$userType" },
														// "address": { "$first": "$address" },
														// "latitude": { "$first": "$latitude" },
														// "longitude": { "$first": "$longitude" },
														// "zipCode": { "$first": "$zipCode" },
														// "contactNo": { "$first": "$contactNo" },
														// "description": { "$first": "$description" },
														// "paymentType": { "$first": "$paymentType" },
														// "paymentStatus": { "$first": "$paymentStatus" },
														// "createdAt": { "$first": "$createdAt" },
														// "updatedAt": { "$first": "$updatedAt" },
														"products": { "$first": "$products" },
														"images": { "$first": "$images" },     
													}
												},
													{
														$project: { 
															user:1,
															shop_id:1,
															product_id : "$orderchilds.product_id",
															qty : "$orderchilds.qty",
															// product_id:1,
															// userType:1,
															// address:1,
															// latitude:1,
															// longitude:1,
															// zipCode:1,
															// contactNo:1,
															// description:1,
															// paymentType:1,
															// paymentStatus:1,
															// createdAt:1,
															// updatedAt:1,
															product_name : "$products.name",
															// live_price : "$products.live_price",
															// online_price : "$products.online_price",
															product_image: {
																$concat:
																[
																// {$cond:[{$eq:['$image', null]}, "", constants.urlPath.base] },
																{$cond:[{$eq:[{$ifNull:["$images.image",constants.urlPath.base]},constants.urlPath.base]},"",constants.urlPath.base]},
																{$ifNull:["$images.image",""]}
																]
															},
															//image:{$concat:[constants.urlPath.base]}
														}
													},
												{ $facet : {payload : [ { $skip: 0 }, {$limit: 100 } ] } }
												]
												if (order_id) {
													order_qry.unshift({ $match: {_id: order_id } });
												}
												Order.aggregate(order_qry).exec((err, result)=>{
													if (err) {
														//console.log("error" ,err)
														return apiResponse.ErrorResponse(res, err);
													}
													if (result) {
														//console.log(result);
														
														return apiResponse.successResponseWithData(res,"Your order successfully.", result[0]);

													}
												});	
												///////////// Select end /////////////
											}
										}); // Order update after pay
								}); // Transaction store end 
							}
							else
							{
								// payment fail message return
								return apiResponse.successResponseWithData(res,"Order Faild.");
								
							}
						}, reason => {
							return apiResponse.successResponseWithData(res,"Order Success.", productData);
						  });
						//return apiResponse.successResponseWithData(res,"Order add Success.", orderData);
					});
				}
			}, reason => {
			return apiResponse.successResponseWithData(res,"Product update Success.", productData);
			});

			/////////////////// Cart data get end///////////////////////////////////
			
		} catch (err) {
			//throw error in json response with status 500. 
			return apiResponse.ErrorResponse(res, err);
		}
	}
];

/**
 * Order update.
 * 
 * @param {string}      category
 * @param {string}      zipCode 
 * @param {string}      description
 * @param {string}      address
 * @param {string}      latitude
 * @param {string}      longitude
 
 * 
 * @returns {Object}
/**
 * Cart update.
 * 
 * @param {string}  shopId 
 * @param {string}  productId
 * @param {string}  userId
 * @param {string}  qty
 * @returns {Object}
 
 * 
 * @returns {Object}
 */
 exports.orderUpdate = [
	auth,
	sanitizeBody("*").escape(),
	(req, res) => {
		try {
			const errors = validationResult(req);

			var order = new Order(
				{ 
					_id:req.params.id
				});
			if(req.body.paymentStatus != ''  && req.body.orderStatus != '')
			{
				order.paymentStatus = req.body.paymentStatus;
				order.orderStatus = req.body.orderStatus;
			}
			else if(req.body.paymentStatus != '')
			{
				order.paymentStatus = req.body.paymentStatus;
			}
			else if(req.body.orderStatus != '')
			{
				order.orderStatus = req.body.orderStatus;
			}
			

			if (!errors.isEmpty()) {
				return apiResponse.validationErrorWithData(res, "Validation Error.", errors.array());
			}
			else {
				if(!mongoose.Types.ObjectId.isValid(req.params.id)){
					return apiResponse.validationErrorWithData(res, "Invalid Error.", "Invalid ID");
				}else{
					Order.findById(req.params.id, function (err, foundOrder) {
						if(foundOrder === null){
							return apiResponse.notFoundResponse(res,"Order not exists with this id");
						}else{
							//Check authorized user
							if(foundOrder.user.toString() !== req.user._id){
								return apiResponse.unauthorizedResponse(res, "You are not authorized to do this operation.");
							}else{
								//update order.
								Order.findByIdAndUpdate(req.params.id, order, {},function (err) {
									if (err) { 
										return apiResponse.ErrorResponse(res, err); 
									}else{
										let order_id = mongoose.Types.ObjectId(req.params.id);
					
										const order_qry = [
											// { $match: {category: cart_id } },
										{
											$lookup:{
												from: 'products', 
												localField:'product_id', 
												foreignField:'_id',
												as:'products'
											}
										},
										{$unwind: '$products'},
										{
											$lookup:{
												from: 'productimages', 
												localField:'products._id', 
												foreignField:'product',
												as:'images'
											},
										},
										{$unwind: '$images'},
										{ 
											"$group": {
												"_id": "$_id",
												"user": { "$first": "$user" },
												"shop_id": { "$first": "$shop_id" },
												"product_id": { "$first": "$product_id" },
												"userType": { "$first": "$userType" },
												"address": { "$first": "$address" },
												"latitude": { "$first": "$latitude" },
												"longitude": { "$first": "$longitude" },
												"zipCode": { "$first": "$zipCode" },
												"contactNo": { "$first": "$contactNo" },
												"description": { "$first": "$description" },
												"paymentType": { "$first": "$paymentType" },
												"paymentStatus": { "$first": "$paymentStatus" },
												"orderStatus": { "$first": "$orderStatus" },
												"createdAt": { "$first": "$createdAt" },
												"updatedAt": { "$first": "$updatedAt" },
												"products": { "$first": "$products" },
												"images": { "$first": "$images" },     
											}
										},
											{
												$project: { 
													user:1,
													shop_id:1,
													product_id:1,
													userType:1,
													address:1,
													latitude:1,
													longitude:1,
													zipCode:1,
													contactNo:1,
													description:1,
													paymentType:1,
													paymentStatus:1,
													orderStatus:1,
													createdAt:1,
													updatedAt:1,
													product_name : "$products.name",
													live_price : "$products.live_price",
													online_price : "$products.online_price",
													product_image: {
														$concat:
														[
														// {$cond:[{$eq:['$image', null]}, "", constants.urlPath.base] },
														{$cond:[{$eq:[{$ifNull:["$images.image",constants.urlPath.base]},constants.urlPath.base]},"",constants.urlPath.base]},
														{$ifNull:["$images.image",""]}
														]
													},
												//	image:{$concat:[constants.urlPath.base]}
												}
											},
										{ $facet : {payload : [ { $skip: 0 }, {$limit: 100 } ] } }
										]
										if (order_id) {
											order_qry.unshift({ $match: {_id: order_id } });
										}
										Order.aggregate(order_qry).exec((err, result)=>{
											if (err) {
												//console.log("error" ,err)
												return apiResponse.ErrorResponse(res, err);
											}
											if (result) {
												//console.log(result);
												return apiResponse.successResponseWithData(res,"Order updated successfully.", result[0].payload[0]);
					
											}
										});
									}
								});
							}
						}
					});
				}
			}
		} catch (err) {
			//throw error in json response with status 500. 
			return apiResponse.ErrorResponse(res, err);
		}
	}
];
